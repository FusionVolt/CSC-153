﻿/**
* 02/14/2018
* CSC 153
* Cameron Scott
* This program builds a sentence
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW2_Scott
{
    public partial class sentence_Builder : Form
    {
        private string letters;
    // This string hold the variable for the words being use in a sentence  

        public sentence_Builder()
        {
            InitializeComponent();
        }


        private void upperCaseAbutton_Click(object sender, EventArgs e)
        {
            letters += "A";
            sentenceLabel.Text = letters;
        }

        private void lowerCaseAbutton_Click(object sender, EventArgs e)
        {
            letters += "a";
            sentenceLabel.Text = letters;
        }

        private void anbutton_Click(object sender, EventArgs e)
        {
            letters += "An";
            sentenceLabel.Text = letters;
        }

        private void spaceButton_Click(object sender, EventArgs e)
        {
            letters += " ";
            sentenceLabel.Text = letters;
        }

        private void anButton1_Click(object sender, EventArgs e)
        {
            letters += "an";
            sentenceLabel.Text = letters;
        }

        private void theButton_Click(object sender, EventArgs e)
        {
            letters += "The";
            sentenceLabel.Text = letters;
        }

        private void theButton1_Click(object sender, EventArgs e)
        {
            letters += "the";
            sentenceLabel.Text = letters;
        }

        private void manButton_Click(object sender, EventArgs e)
        {
            letters += "man";
            sentenceLabel.Text = letters;
        }

        private void womanButton_Click(object sender, EventArgs e)
        {
            letters += "woman";
            sentenceLabel.Text = letters;
        }

        private void dogButton_Click(object sender, EventArgs e)
        {
            letters += "dog";
            sentenceLabel.Text = letters;

        }

        private void catButton_Click(object sender, EventArgs e)
        {
            letters += "cat";
            sentenceLabel.Text = letters;
        }

        private void carButton_Click(object sender, EventArgs e)
        {
            letters += "car";
            sentenceLabel.Text = letters;
        }

        private void bicyleButton_Click(object sender, EventArgs e)
        {
            letters += "bicyle";
            sentenceLabel.Text = letters;
        }

        private void beautifulButton_Click(object sender, EventArgs e)
        {
            letters += "beautiful";
            sentenceLabel.Text = letters;
        }

        private void bigButton_Click(object sender, EventArgs e)
        {
            letters += "big";
            sentenceLabel.Text = letters;
        }

        private void smallButton_Click(object sender, EventArgs e)
        {

            letters += "small";
            sentenceLabel.Text = letters;
        }

        private void strangeButton_Click(object sender, EventArgs e)
        {
            letters += "strange";
            sentenceLabel.Text = letters;
        }

        private void lookButton_Click(object sender, EventArgs e)
        {
            letters += "look at";
            sentenceLabel.Text = letters;
        }

        private void rodebutton_Click(object sender, EventArgs e)
        {
            letters += "rode";
            sentenceLabel.Text = letters;
        }

        private void spokeButton_Click(object sender, EventArgs e)
        {
            letters += "spoke";
            sentenceLabel.Text = letters;
        }

        private void laughedButton_Click(object sender, EventArgs e)
        {
            letters += "laughed at";
            sentenceLabel.Text = letters;
        }

        private void droveButton_Click(object sender, EventArgs e)
        {
            letters += "drove";
            sentenceLabel.Text = letters;
        }

        private void periodButton_Click(object sender, EventArgs e)
        {
            letters += ".";
            sentenceLabel.Text = letters;
        }

        private void exclamationPointButton_Click(object sender, EventArgs e)
        {
            letters += "!";
            sentenceLabel.Text = letters;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
        // This clears the sentence label.
            sentenceLabel.Text = "";
            letters = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
        // This closes the program
            this.Close();
        }
    }
}
