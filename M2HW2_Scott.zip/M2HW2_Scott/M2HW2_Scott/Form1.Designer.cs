﻿namespace M2HW2_Scott
{
    partial class sentence_Builder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.upperCaseAbutton = new System.Windows.Forms.Button();
            this.lowerCaseAbutton = new System.Windows.Forms.Button();
            this.anbutton = new System.Windows.Forms.Button();
            this.anButton1 = new System.Windows.Forms.Button();
            this.theButton = new System.Windows.Forms.Button();
            this.theButton1 = new System.Windows.Forms.Button();
            this.manButton = new System.Windows.Forms.Button();
            this.womanButton = new System.Windows.Forms.Button();
            this.dogButton = new System.Windows.Forms.Button();
            this.catButton = new System.Windows.Forms.Button();
            this.carButton = new System.Windows.Forms.Button();
            this.bicyleButton = new System.Windows.Forms.Button();
            this.beautifulButton = new System.Windows.Forms.Button();
            this.bigButton = new System.Windows.Forms.Button();
            this.smallButton = new System.Windows.Forms.Button();
            this.strangeButton = new System.Windows.Forms.Button();
            this.lookButton = new System.Windows.Forms.Button();
            this.rodebutton = new System.Windows.Forms.Button();
            this.spokeButton = new System.Windows.Forms.Button();
            this.laughedButton = new System.Windows.Forms.Button();
            this.droveButton = new System.Windows.Forms.Button();
            this.spaceButton = new System.Windows.Forms.Button();
            this.periodButton = new System.Windows.Forms.Button();
            this.exclamationPointButton = new System.Windows.Forms.Button();
            this.sentenceLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // upperCaseAbutton
            // 
            this.upperCaseAbutton.Location = new System.Drawing.Point(140, 39);
            this.upperCaseAbutton.Name = "upperCaseAbutton";
            this.upperCaseAbutton.Size = new System.Drawing.Size(38, 23);
            this.upperCaseAbutton.TabIndex = 1;
            this.upperCaseAbutton.Text = "A";
            this.upperCaseAbutton.UseVisualStyleBackColor = true;
            this.upperCaseAbutton.Click += new System.EventHandler(this.upperCaseAbutton_Click);
            // 
            // lowerCaseAbutton
            // 
            this.lowerCaseAbutton.Location = new System.Drawing.Point(195, 39);
            this.lowerCaseAbutton.Name = "lowerCaseAbutton";
            this.lowerCaseAbutton.Size = new System.Drawing.Size(33, 23);
            this.lowerCaseAbutton.TabIndex = 2;
            this.lowerCaseAbutton.Text = "a";
            this.lowerCaseAbutton.UseVisualStyleBackColor = true;
            this.lowerCaseAbutton.Click += new System.EventHandler(this.lowerCaseAbutton_Click);
            // 
            // anbutton
            // 
            this.anbutton.Location = new System.Drawing.Point(253, 39);
            this.anbutton.Name = "anbutton";
            this.anbutton.Size = new System.Drawing.Size(43, 23);
            this.anbutton.TabIndex = 3;
            this.anbutton.Text = "An";
            this.anbutton.UseVisualStyleBackColor = true;
            this.anbutton.Click += new System.EventHandler(this.anbutton_Click);
            // 
            // anButton1
            // 
            this.anButton1.Location = new System.Drawing.Point(314, 39);
            this.anButton1.Name = "anButton1";
            this.anButton1.Size = new System.Drawing.Size(41, 23);
            this.anButton1.TabIndex = 4;
            this.anButton1.Text = "an";
            this.anButton1.UseVisualStyleBackColor = true;
            this.anButton1.Click += new System.EventHandler(this.anButton1_Click);
            // 
            // theButton
            // 
            this.theButton.Location = new System.Drawing.Point(380, 39);
            this.theButton.Name = "theButton";
            this.theButton.Size = new System.Drawing.Size(37, 23);
            this.theButton.TabIndex = 5;
            this.theButton.Text = "The";
            this.theButton.UseVisualStyleBackColor = true;
            this.theButton.Click += new System.EventHandler(this.theButton_Click);
            // 
            // theButton1
            // 
            this.theButton1.Location = new System.Drawing.Point(441, 39);
            this.theButton1.Name = "theButton1";
            this.theButton1.Size = new System.Drawing.Size(38, 23);
            this.theButton1.TabIndex = 6;
            this.theButton1.Text = "the";
            this.theButton1.UseVisualStyleBackColor = true;
            this.theButton1.Click += new System.EventHandler(this.theButton1_Click);
            // 
            // manButton
            // 
            this.manButton.Location = new System.Drawing.Point(108, 91);
            this.manButton.Name = "manButton";
            this.manButton.Size = new System.Drawing.Size(48, 23);
            this.manButton.TabIndex = 7;
            this.manButton.Text = "man";
            this.manButton.UseVisualStyleBackColor = true;
            this.manButton.Click += new System.EventHandler(this.manButton_Click);
            // 
            // womanButton
            // 
            this.womanButton.Location = new System.Drawing.Point(195, 91);
            this.womanButton.Name = "womanButton";
            this.womanButton.Size = new System.Drawing.Size(56, 23);
            this.womanButton.TabIndex = 8;
            this.womanButton.Text = "woman";
            this.womanButton.UseVisualStyleBackColor = true;
            this.womanButton.Click += new System.EventHandler(this.womanButton_Click);
            // 
            // dogButton
            // 
            this.dogButton.Location = new System.Drawing.Point(277, 91);
            this.dogButton.Name = "dogButton";
            this.dogButton.Size = new System.Drawing.Size(48, 23);
            this.dogButton.TabIndex = 9;
            this.dogButton.Text = "dog";
            this.dogButton.UseVisualStyleBackColor = true;
            this.dogButton.Click += new System.EventHandler(this.dogButton_Click);
            // 
            // catButton
            // 
            this.catButton.Location = new System.Drawing.Point(344, 91);
            this.catButton.Name = "catButton";
            this.catButton.Size = new System.Drawing.Size(48, 23);
            this.catButton.TabIndex = 10;
            this.catButton.Text = "cat";
            this.catButton.UseVisualStyleBackColor = true;
            this.catButton.Click += new System.EventHandler(this.catButton_Click);
            // 
            // carButton
            // 
            this.carButton.Location = new System.Drawing.Point(415, 91);
            this.carButton.Name = "carButton";
            this.carButton.Size = new System.Drawing.Size(48, 23);
            this.carButton.TabIndex = 11;
            this.carButton.Text = "car";
            this.carButton.UseVisualStyleBackColor = true;
            this.carButton.Click += new System.EventHandler(this.carButton_Click);
            // 
            // bicyleButton
            // 
            this.bicyleButton.Location = new System.Drawing.Point(490, 91);
            this.bicyleButton.Name = "bicyleButton";
            this.bicyleButton.Size = new System.Drawing.Size(48, 23);
            this.bicyleButton.TabIndex = 12;
            this.bicyleButton.Text = "bicyle";
            this.bicyleButton.UseVisualStyleBackColor = true;
            this.bicyleButton.Click += new System.EventHandler(this.bicyleButton_Click);
            // 
            // beautifulButton
            // 
            this.beautifulButton.Location = new System.Drawing.Point(140, 130);
            this.beautifulButton.Name = "beautifulButton";
            this.beautifulButton.Size = new System.Drawing.Size(60, 23);
            this.beautifulButton.TabIndex = 13;
            this.beautifulButton.Text = "beautiful";
            this.beautifulButton.UseVisualStyleBackColor = true;
            this.beautifulButton.Click += new System.EventHandler(this.beautifulButton_Click);
            // 
            // bigButton
            // 
            this.bigButton.Location = new System.Drawing.Point(232, 130);
            this.bigButton.Name = "bigButton";
            this.bigButton.Size = new System.Drawing.Size(48, 23);
            this.bigButton.TabIndex = 14;
            this.bigButton.Text = "big";
            this.bigButton.UseVisualStyleBackColor = true;
            this.bigButton.Click += new System.EventHandler(this.bigButton_Click);
            // 
            // smallButton
            // 
            this.smallButton.Location = new System.Drawing.Point(314, 130);
            this.smallButton.Name = "smallButton";
            this.smallButton.Size = new System.Drawing.Size(48, 23);
            this.smallButton.TabIndex = 15;
            this.smallButton.Text = "small";
            this.smallButton.UseVisualStyleBackColor = true;
            this.smallButton.Click += new System.EventHandler(this.smallButton_Click);
            // 
            // strangeButton
            // 
            this.strangeButton.Location = new System.Drawing.Point(396, 130);
            this.strangeButton.Name = "strangeButton";
            this.strangeButton.Size = new System.Drawing.Size(56, 23);
            this.strangeButton.TabIndex = 16;
            this.strangeButton.Text = "strange";
            this.strangeButton.UseVisualStyleBackColor = true;
            this.strangeButton.Click += new System.EventHandler(this.strangeButton_Click);
            // 
            // lookButton
            // 
            this.lookButton.Location = new System.Drawing.Point(73, 170);
            this.lookButton.Name = "lookButton";
            this.lookButton.Size = new System.Drawing.Size(74, 23);
            this.lookButton.TabIndex = 17;
            this.lookButton.Text = "looked at";
            this.lookButton.UseVisualStyleBackColor = true;
            this.lookButton.Click += new System.EventHandler(this.lookButton_Click);
            // 
            // rodebutton
            // 
            this.rodebutton.Location = new System.Drawing.Point(180, 170);
            this.rodebutton.Name = "rodebutton";
            this.rodebutton.Size = new System.Drawing.Size(48, 23);
            this.rodebutton.TabIndex = 18;
            this.rodebutton.Text = "rode";
            this.rodebutton.UseVisualStyleBackColor = true;
            this.rodebutton.Click += new System.EventHandler(this.rodebutton_Click);
            // 
            // spokeButton
            // 
            this.spokeButton.Location = new System.Drawing.Point(267, 170);
            this.spokeButton.Name = "spokeButton";
            this.spokeButton.Size = new System.Drawing.Size(48, 23);
            this.spokeButton.TabIndex = 19;
            this.spokeButton.Text = "spoke to";
            this.spokeButton.UseVisualStyleBackColor = true;
            this.spokeButton.Click += new System.EventHandler(this.spokeButton_Click);
            // 
            // laughedButton
            // 
            this.laughedButton.Location = new System.Drawing.Point(362, 170);
            this.laughedButton.Name = "laughedButton";
            this.laughedButton.Size = new System.Drawing.Size(67, 23);
            this.laughedButton.TabIndex = 20;
            this.laughedButton.Text = "laughed at";
            this.laughedButton.UseVisualStyleBackColor = true;
            this.laughedButton.Click += new System.EventHandler(this.laughedButton_Click);
            // 
            // droveButton
            // 
            this.droveButton.Location = new System.Drawing.Point(460, 170);
            this.droveButton.Name = "droveButton";
            this.droveButton.Size = new System.Drawing.Size(51, 23);
            this.droveButton.TabIndex = 21;
            this.droveButton.Text = "drove";
            this.droveButton.UseVisualStyleBackColor = true;
            this.droveButton.Click += new System.EventHandler(this.droveButton_Click);
            // 
            // spaceButton
            // 
            this.spaceButton.Location = new System.Drawing.Point(168, 224);
            this.spaceButton.Name = "spaceButton";
            this.spaceButton.Size = new System.Drawing.Size(70, 31);
            this.spaceButton.TabIndex = 22;
            this.spaceButton.Text = "(space)";
            this.spaceButton.UseVisualStyleBackColor = true;
            this.spaceButton.Click += new System.EventHandler(this.spaceButton_Click);
            // 
            // periodButton
            // 
            this.periodButton.Location = new System.Drawing.Point(267, 224);
            this.periodButton.Name = "periodButton";
            this.periodButton.Size = new System.Drawing.Size(48, 31);
            this.periodButton.TabIndex = 23;
            this.periodButton.Text = ".";
            this.periodButton.UseVisualStyleBackColor = true;
            this.periodButton.Click += new System.EventHandler(this.periodButton_Click);
            // 
            // exclamationPointButton
            // 
            this.exclamationPointButton.Location = new System.Drawing.Point(344, 224);
            this.exclamationPointButton.Name = "exclamationPointButton";
            this.exclamationPointButton.Size = new System.Drawing.Size(48, 31);
            this.exclamationPointButton.TabIndex = 24;
            this.exclamationPointButton.Text = "!";
            this.exclamationPointButton.UseVisualStyleBackColor = true;
            this.exclamationPointButton.Click += new System.EventHandler(this.exclamationPointButton_Click);
            // 
            // sentenceLabel
            // 
            this.sentenceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sentenceLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sentenceLabel.Location = new System.Drawing.Point(12, 283);
            this.sentenceLabel.Name = "sentenceLabel";
            this.sentenceLabel.Size = new System.Drawing.Size(570, 23);
            this.sentenceLabel.TabIndex = 25;
            this.sentenceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // clearButton
            // 
            this.clearButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.Location = new System.Drawing.Point(191, 321);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 32);
            this.clearButton.TabIndex = 26;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(314, 321);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 32);
            this.exitButton.TabIndex = 27;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // sentence_Builder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 365);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.sentenceLabel);
            this.Controls.Add(this.exclamationPointButton);
            this.Controls.Add(this.periodButton);
            this.Controls.Add(this.spaceButton);
            this.Controls.Add(this.droveButton);
            this.Controls.Add(this.laughedButton);
            this.Controls.Add(this.spokeButton);
            this.Controls.Add(this.rodebutton);
            this.Controls.Add(this.lookButton);
            this.Controls.Add(this.strangeButton);
            this.Controls.Add(this.smallButton);
            this.Controls.Add(this.bigButton);
            this.Controls.Add(this.beautifulButton);
            this.Controls.Add(this.bicyleButton);
            this.Controls.Add(this.carButton);
            this.Controls.Add(this.catButton);
            this.Controls.Add(this.dogButton);
            this.Controls.Add(this.womanButton);
            this.Controls.Add(this.manButton);
            this.Controls.Add(this.theButton1);
            this.Controls.Add(this.theButton);
            this.Controls.Add(this.anButton1);
            this.Controls.Add(this.anbutton);
            this.Controls.Add(this.lowerCaseAbutton);
            this.Controls.Add(this.upperCaseAbutton);
            this.Name = "sentence_Builder";
            this.Text = "Sentence Builder";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button upperCaseAbutton;
        private System.Windows.Forms.Button lowerCaseAbutton;
        private System.Windows.Forms.Button anbutton;
        private System.Windows.Forms.Button anButton1;
        private System.Windows.Forms.Button theButton;
        private System.Windows.Forms.Button theButton1;
        private System.Windows.Forms.Button manButton;
        private System.Windows.Forms.Button womanButton;
        private System.Windows.Forms.Button dogButton;
        private System.Windows.Forms.Button catButton;
        private System.Windows.Forms.Button carButton;
        private System.Windows.Forms.Button bicyleButton;
        private System.Windows.Forms.Button beautifulButton;
        private System.Windows.Forms.Button bigButton;
        private System.Windows.Forms.Button smallButton;
        private System.Windows.Forms.Button strangeButton;
        private System.Windows.Forms.Button lookButton;
        private System.Windows.Forms.Button rodebutton;
        private System.Windows.Forms.Button spokeButton;
        private System.Windows.Forms.Button laughedButton;
        private System.Windows.Forms.Button droveButton;
        private System.Windows.Forms.Button spaceButton;
        private System.Windows.Forms.Button periodButton;
        private System.Windows.Forms.Button exclamationPointButton;
        private System.Windows.Forms.Label sentenceLabel;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

