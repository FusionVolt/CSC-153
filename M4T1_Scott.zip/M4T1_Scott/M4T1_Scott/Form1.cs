﻿/**
* 03/18/2018
* CSC 153
* Cameron Scott
* This program converts KPH to MPH.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M4T1_Scott
{
    public partial class speedForm : Form
    {
        public speedForm()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // Constants
            // It'll always be the same value of what number or text you put in the variable
            const int START_SPEED = 60;
            const int END_SPEED = 130;
            const int INTERVAL = 10;
            const double CONVERSION_FACTOR = 0.6214;

            // Variables
            int kph;        // Kilometers per hour
            double mph;     // Miles per hour

            // Display the table of speeds.
            // The staring speed is 60. The "+=" will repeat the number of the veriable selected within the "for" loop.
            // The INTERVAL variable will add on top the START SPEED variable each loop.
            // The loop continues until it be becomes greater than the END SPEED variable.
            for (kph = START_SPEED; kph <= END_SPEED; kph += INTERVAL)
            {
                // Calculate miles per hour.
                mph = kph * CONVERSION_FACTOR;

                // Display the conversion.
                outputListBox.Items.Add(kph + " Kph is the same as " + mph + " MPH");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form.
            this.Close();
        }
    }
}
