﻿/**
 * 02/13/2018
 * CSC 153
 * Cameron Scott, Justin Weihl, and Alex Lopez
 * This program calculates the total revenue of tickets sold.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW3_Group_11_
{
    public partial class stadiumSeatingForm : Form
    {
        public stadiumSeatingForm()
        {
            InitializeComponent();
        }

        
        public void calcRevButton_Click(object sender, EventArgs e)
        {
            // Calculate the number of tickets sold from each class
            // "n2" in .ToString represents the number of decimal places
            double class_A;
            class_A = double.Parse(classATextBox.Text) * 15;
            classArevenueLabel.Text = class_A.ToString("n2");

            double class_B;
            class_B = double.Parse(classBTextBox.Text) * 12;
            classBrevenueLabel.Text = class_B.ToString("n2");

            double class_C;
            class_C = double.Parse(classCTextBox.Text) * 9;
            classCRevenueLabel.Text = class_C.ToString("n2");

            // Calculate for classes

           double average;
           average = class_A + class_B + class_C;

           // Calculate total

           totalRevenueLable.Text = average.ToString("n2");
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //clear
            classATextBox.Text = "";
            classBTextBox.Text = "";
            classCTextBox.Text = "";
            classArevenueLabel.Text = "";
            classBrevenueLabel.Text = "";
            classCRevenueLabel.Text = "";
            totalRevenueLable.Text = "";

        }

        private void exitButtion_Click(object sender, EventArgs e)
        {
            //close
            this.Close();

        }
    }
}
