﻿namespace M2HW3_Group_11_
{
    partial class stadiumSeatingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip3 = new System.Windows.Forms.ToolTip(this.components);
            this.ticketGroupBox = new System.Windows.Forms.GroupBox();
            this.classCTextBox = new System.Windows.Forms.TextBox();
            this.classBTextBox = new System.Windows.Forms.TextBox();
            this.classATextBox = new System.Windows.Forms.TextBox();
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.classCLabel = new System.Windows.Forms.Label();
            this.classBLable = new System.Windows.Forms.Label();
            this.classALable = new System.Windows.Forms.Label();
            this.revenueGroupBox = new System.Windows.Forms.GroupBox();
            this.totalRevenueLable = new System.Windows.Forms.Label();
            this.classCRevenueLabel = new System.Windows.Forms.Label();
            this.classBrevenueLabel = new System.Windows.Forms.Label();
            this.classArevenueLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.classC1Label = new System.Windows.Forms.Label();
            this.classB1Label = new System.Windows.Forms.Label();
            this.classA1Label = new System.Windows.Forms.Label();
            this.calcRevButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButtion = new System.Windows.Forms.Button();
            this.ticketGroupBox.SuspendLayout();
            this.revenueGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // ticketGroupBox
            // 
            this.ticketGroupBox.Controls.Add(this.classCTextBox);
            this.ticketGroupBox.Controls.Add(this.classBTextBox);
            this.ticketGroupBox.Controls.Add(this.classATextBox);
            this.ticketGroupBox.Controls.Add(this.descriptionLabel);
            this.ticketGroupBox.Controls.Add(this.classCLabel);
            this.ticketGroupBox.Controls.Add(this.classBLable);
            this.ticketGroupBox.Controls.Add(this.classALable);
            this.ticketGroupBox.Location = new System.Drawing.Point(8, 29);
            this.ticketGroupBox.Name = "ticketGroupBox";
            this.ticketGroupBox.Size = new System.Drawing.Size(250, 205);
            this.ticketGroupBox.TabIndex = 0;
            this.ticketGroupBox.TabStop = false;
            this.ticketGroupBox.Text = "Tickets Sold";
            // 
            // classCTextBox
            // 
            this.classCTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.classCTextBox.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.classCTextBox.Location = new System.Drawing.Point(108, 150);
            this.classCTextBox.Name = "classCTextBox";
            this.classCTextBox.Size = new System.Drawing.Size(100, 20);
            this.classCTextBox.TabIndex = 6;
//            this.classCTextBox.TextChanged += new System.EventHandler(this.classCTextBox_TextChanged);
            // 
            // classBTextBox
            // 
            this.classBTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.classBTextBox.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.classBTextBox.Location = new System.Drawing.Point(108, 117);
            this.classBTextBox.Name = "classBTextBox";
            this.classBTextBox.Size = new System.Drawing.Size(100, 20);
            this.classBTextBox.TabIndex = 5;
//            this.classBTextBox.TextChanged += new System.EventHandler(this.classBTextBox_TextChanged);
            // 
            // classATextBox
            // 
            this.classATextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.classATextBox.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.classATextBox.Location = new System.Drawing.Point(108, 85);
            this.classATextBox.Name = "classATextBox";
            this.classATextBox.Size = new System.Drawing.Size(100, 20);
            this.classATextBox.TabIndex = 4;
//            this.classATextBox.TextChanged += new System.EventHandler(this.classATextBox_TextChanged);
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.Location = new System.Drawing.Point(31, 34);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.Size = new System.Drawing.Size(177, 34);
            this.descriptionLabel.TabIndex = 3;
            this.descriptionLabel.Text = "Enter the number of tickets sold for each class of seats.";
            // 
            // classCLabel
            // 
            this.classCLabel.Location = new System.Drawing.Point(12, 148);
            this.classCLabel.Name = "classCLabel";
            this.classCLabel.Size = new System.Drawing.Size(100, 23);
            this.classCLabel.TabIndex = 2;
            this.classCLabel.Text = "Class C:";
            this.classCLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // classBLable
            // 
            this.classBLable.Location = new System.Drawing.Point(12, 114);
            this.classBLable.Name = "classBLable";
            this.classBLable.Size = new System.Drawing.Size(100, 23);
            this.classBLable.TabIndex = 1;
            this.classBLable.Text = "Class B:";
            this.classBLable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // classALable
            // 
            this.classALable.Location = new System.Drawing.Point(12, 82);
            this.classALable.Name = "classALable";
            this.classALable.Size = new System.Drawing.Size(100, 23);
            this.classALable.TabIndex = 0;
            this.classALable.Text = "Class A:";
            this.classALable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // revenueGroupBox
            // 
            this.revenueGroupBox.Controls.Add(this.totalRevenueLable);
            this.revenueGroupBox.Controls.Add(this.classCRevenueLabel);
            this.revenueGroupBox.Controls.Add(this.classBrevenueLabel);
            this.revenueGroupBox.Controls.Add(this.classArevenueLabel);
            this.revenueGroupBox.Controls.Add(this.totalLabel);
            this.revenueGroupBox.Controls.Add(this.classC1Label);
            this.revenueGroupBox.Controls.Add(this.classB1Label);
            this.revenueGroupBox.Controls.Add(this.classA1Label);
            this.revenueGroupBox.Location = new System.Drawing.Point(309, 29);
            this.revenueGroupBox.Name = "revenueGroupBox";
            this.revenueGroupBox.Size = new System.Drawing.Size(232, 205);
            this.revenueGroupBox.TabIndex = 1;
            this.revenueGroupBox.TabStop = false;
            this.revenueGroupBox.Text = "Revenue Generated";
            // 
            // totalRevenueLable
            // 
            this.totalRevenueLable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalRevenueLable.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalRevenueLable.Location = new System.Drawing.Point(86, 150);
            this.totalRevenueLable.Name = "totalRevenueLable";
            this.totalRevenueLable.Size = new System.Drawing.Size(100, 23);
            this.totalRevenueLable.TabIndex = 15;
            this.totalRevenueLable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
//            this.totalRevenueLable.Click += new System.EventHandler(this.totalRevenueLable_Click);
            // 
            // classCRevenueLabel
            // 
            this.classCRevenueLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.classCRevenueLabel.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.classCRevenueLabel.Location = new System.Drawing.Point(86, 117);
            this.classCRevenueLabel.Name = "classCRevenueLabel";
            this.classCRevenueLabel.Size = new System.Drawing.Size(100, 23);
            this.classCRevenueLabel.TabIndex = 14;
            this.classCRevenueLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
//            this.classCRevenueLabel.Click += new System.EventHandler(this.classCRevenueLabel_Click);
            // 
            // classBrevenueLabel
            // 
            this.classBrevenueLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.classBrevenueLabel.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.classBrevenueLabel.Location = new System.Drawing.Point(86, 85);
            this.classBrevenueLabel.Name = "classBrevenueLabel";
            this.classBrevenueLabel.Size = new System.Drawing.Size(100, 23);
            this.classBrevenueLabel.TabIndex = 12;
            this.classBrevenueLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
//            this.classBrevenueLabel.Click += new System.EventHandler(this.classBrevenueLabel_Click);
            // 
            // classArevenueLabel
            // 
            this.classArevenueLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.classArevenueLabel.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.classArevenueLabel.Location = new System.Drawing.Point(86, 55);
            this.classArevenueLabel.Name = "classArevenueLabel";
            this.classArevenueLabel.Size = new System.Drawing.Size(100, 23);
            this.classArevenueLabel.TabIndex = 11;
            this.classArevenueLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
//            this.classArevenueLabel.Click += new System.EventHandler(this.classArevenueLabel_Click);
            // 
            // totalLabel
            // 
            this.totalLabel.Location = new System.Drawing.Point(20, 150);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(60, 23);
            this.totalLabel.TabIndex = 10;
            this.totalLabel.Text = "Total:";
            this.totalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // classC1Label
            // 
            this.classC1Label.Location = new System.Drawing.Point(20, 117);
            this.classC1Label.Name = "classC1Label";
            this.classC1Label.Size = new System.Drawing.Size(60, 23);
            this.classC1Label.TabIndex = 9;
            this.classC1Label.Text = "Class C:";
            this.classC1Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // classB1Label
            // 
            this.classB1Label.Location = new System.Drawing.Point(20, 85);
            this.classB1Label.Name = "classB1Label";
            this.classB1Label.Size = new System.Drawing.Size(60, 23);
            this.classB1Label.TabIndex = 8;
            this.classB1Label.Text = "Class B:";
            this.classB1Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // classA1Label
            // 
            this.classA1Label.Location = new System.Drawing.Point(20, 55);
            this.classA1Label.Name = "classA1Label";
            this.classA1Label.Size = new System.Drawing.Size(60, 23);
            this.classA1Label.TabIndex = 7;
            this.classA1Label.Text = "Class A:";
            this.classA1Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calcRevButton
            // 
            this.calcRevButton.Location = new System.Drawing.Point(141, 273);
            this.calcRevButton.Name = "calcRevButton";
            this.calcRevButton.Size = new System.Drawing.Size(75, 35);
            this.calcRevButton.TabIndex = 16;
            this.calcRevButton.Text = "Calculate Revenue";
            this.calcRevButton.UseVisualStyleBackColor = true;
            this.calcRevButton.Click += new System.EventHandler(this.calcRevButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(244, 273);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 35);
            this.clearButton.TabIndex = 17;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButtion
            // 
            this.exitButtion.Location = new System.Drawing.Point(349, 273);
            this.exitButtion.Name = "exitButtion";
            this.exitButtion.Size = new System.Drawing.Size(75, 35);
            this.exitButtion.TabIndex = 18;
            this.exitButtion.Text = "Exit";
            this.exitButtion.UseVisualStyleBackColor = true;
            this.exitButtion.Click += new System.EventHandler(this.exitButtion_Click);
            // 
            // stadiumSeatingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 369);
            this.Controls.Add(this.exitButtion);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calcRevButton);
            this.Controls.Add(this.revenueGroupBox);
            this.Controls.Add(this.ticketGroupBox);
            this.Name = "stadiumSeatingForm";
            this.Text = "Stadium Seating";
            this.ticketGroupBox.ResumeLayout(false);
            this.ticketGroupBox.PerformLayout();
            this.revenueGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.ToolTip toolTip3;
        private System.Windows.Forms.GroupBox ticketGroupBox;
        private System.Windows.Forms.TextBox classCTextBox;
        private System.Windows.Forms.TextBox classBTextBox;
        private System.Windows.Forms.TextBox classATextBox;
        private System.Windows.Forms.Label descriptionLabel;
        private System.Windows.Forms.Label classCLabel;
        private System.Windows.Forms.Label classBLable;
        private System.Windows.Forms.Label classALable;
        private System.Windows.Forms.GroupBox revenueGroupBox;
        private System.Windows.Forms.Label classA1Label;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Label classC1Label;
        private System.Windows.Forms.Label classB1Label;
        private System.Windows.Forms.Label classBrevenueLabel;
        private System.Windows.Forms.Label classArevenueLabel;
        private System.Windows.Forms.Label totalRevenueLable;
        private System.Windows.Forms.Label classCRevenueLabel;
        private System.Windows.Forms.Button calcRevButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButtion;
    }
}

