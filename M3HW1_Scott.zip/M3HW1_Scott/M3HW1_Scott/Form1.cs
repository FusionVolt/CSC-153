﻿/**
* 02/28/2018
* CSC 153
* Cameron Scott
* This program converts numbers into roman numerals
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW1_Scott
{
    public partial class oneTenLabel : Form
    {
        public oneTenLabel()
        {
            InitializeComponent();
      
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
           int number;

            if (int.TryParse(oneTenTextBox.Text, out number)) // This prevents users from typing anything but a number.
            {
                // This code converts numbers to roman numberals using switch statements.
                switch (number)
                {
                    case 1:
                        romanLabel.Text = "I";
                        break;
                    case 2:
                        romanLabel.Text = "II";
                        break;
                    case 3:
                        romanLabel.Text = "III";
                        break;
                    case 4:
                        romanLabel.Text = "IV";
                        break;
                    case 5:
                        romanLabel.Text = "V";
                        break;
                    case 6:
                        romanLabel.Text = "VI";
                        break;
                    case 7:
                        romanLabel.Text = "VII";
                        break;
                    case 8:
                        romanLabel.Text = "VIII";
                        break;
                    case 9:
                        romanLabel.Text = "IX";
                        break;
                    case 10:
                        romanLabel.Text = "X";
                        break;
                    default:
                        MessageBox.Show("Please choose numbers 1 through 10");
                        
                        break;
                }
            }
            else
            {
                MessageBox.Show("Invalid input for numbers");
                oneTenTextBox.Text = "";
            }
            
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // This will reset the label and text box.
            oneTenTextBox.Text = "";
            romanLabel.Text = "";

            // Reset the focus back to textbox.
            oneTenTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // This closes the program.
            this.Close();
        }
    }
}
