﻿/**
* 4/20/2018
* CSC 153
* Cameron Scott
* This program calculates the total cost of parts and maintenance using methods
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M6HW2_Scott
{
    public partial class automotiveForm : Form
    {
        public automotiveForm()
        {
            InitializeComponent();
        }
        // Variables
        double total;           // Accumulation of all charges collected to sub-total
        double parts;           // A separate charge that is taxed
        double labor;           // A charge a mechcanic worked on customer's vehicle
        double grandTotal;      // All charges finalized

        // A method for Oil and Lube
        private void OilLubeCharges()
        // A if statement will determine if a customer needs an oil change and/or lube change.
        {
            if (oilCheckBox.Checked)
            {
                oilCheckBox.Checked = true;
                total += 26.00;
            }
            
            if (lubeCheckBox.Checked)
            {
                lubeCheckBox.Checked = true;
                total += 18.00;
            }
            serviceLaborLabel.Text = total.ToString();
        }

        // This method clears the checkboxes for 'OilLubeCharges" method.
        private void ClearOilLube()
        {

            if (oilCheckBox.Checked)
            {
                oilCheckBox.Checked = false;               
            }

            if (lubeCheckBox.Checked)
            {
                lubeCheckBox.Checked = false;
            }
            // "total = 0" is what's preventing a accumulation from happening from all methods upon clearing infomation.
            // For example: Without "total = 0", when I calculate the cost in the summary,
            // it retains the number when I clear the infomation, thus adding on top of what my next calculation and so on
            total = 0;
            serviceLaborLabel.Text = "";
        }

        // this if statment determines if a customer needs a radiator and/or transmission fix.
        private void FlushCharges()
        {
            if (radiatorCheckBox.Checked)
            {
                radiatorCheckBox.Checked = true;
                total += 30.00;
            }

            if (TransmissionCheckBox.Checked)
            {
                TransmissionCheckBox.Checked = true;
                total += 80.00;
            }
            serviceLaborLabel.Text = total.ToString();
        }

        // This method clears the checkboxes for "FlushCharges" method.
        private void ClearFlushes()
        {
            if (radiatorCheckBox.Checked)
            {
                radiatorCheckBox.Checked = false;
            }

            if (TransmissionCheckBox.Checked)
            {
                TransmissionCheckBox.Checked = false;
            }
            serviceLaborLabel.Text = "";
        }

        // This if statement determine if a customer needs an inspection, muffler change, and/or tire rotation
        private void MiscCharges()
        {
            if (InspectionCheckBox.Checked)
            {
                InspectionCheckBox.Checked = true;
                total += 15.00; 
            }

            if (MufflerCheckBox.Checked)
            {
                MufflerCheckBox.Checked = true;
                total += 100.00;
            }
            
            if (TireCheckBox.Checked)
            {
                TireCheckBox.Checked = true;
                total += 20.00;
            }
            serviceLaborLabel.Text = total.ToString();
        }

        // This method clears the checkboxes for "MiseCharges" method.
        private void ClearMisc()
        {
            if (InspectionCheckBox.Checked)
            {
                InspectionCheckBox.Checked = false;
            }

            if (MufflerCheckBox.Checked)
            {
                MufflerCheckBox.Checked = false;
            }

            if (TireCheckBox.Checked)
            {
                TireCheckBox.Checked = false;
            }
            serviceLaborLabel.Text = "";
        }

        // This method allows a customer add in the price for parts and labor.
        private void OtherCharges()
        {

            if (double.TryParse(partsTextBox.Text, out parts))
            {
                if (double.TryParse(laborTextBox.Text, out labor))
                {
                    total += labor;
                    serviceLaborLabel.Text = total.ToString("C");
                    partsLabel.Text = parts.ToString("C");                   
                }
                else
                {
                    MessageBox.Show("Invalid input for number.");
                }

            }
            else
            {
                MessageBox.Show("Invalid input for number");
            }
        }

        // This method clears the checkboxes for "OtherCharges" method.
        private void ClearOther()
        {
            partsTextBox.Text = "";
            laborTextBox.Text = "";
            partsTextBox.Focus();
        }

        // This calculates the tax for parts only.
        private void TaxCharges()
        {
            double tax = .06;
            double taxParts = parts * tax;
            total += taxParts;
            taxLabel.Text = taxParts.ToString("C");
            totalFeesLabel.Text = taxParts.ToString("C");
        }

        // This calculates all the fees for the grand total.
        private void TotalCharges()
        {
            OilLubeCharges();
            FlushCharges();
            MiscCharges();
            OtherCharges();
            TaxCharges();
            grandTotal = total + parts;
            totalFeesLabel.Text = grandTotal.ToString("C");
        }
        
        // This method clears out the fees in the summary.
        private void ClearFees()
        {
            serviceLaborLabel.Text = "";
            partsLabel.Text = "";
            taxLabel.Text = "";
            totalFeesLabel.Text = "";
        }


        private void calculateButton_Click_1(object sender, EventArgs e)
        {
            // This passess all the other methods within this method.
           TotalCharges();
        }


        private void ExitButton_Click(object sender, EventArgs e)
        {
            // This closes the program.
            this.Close();
        }

        private void ClearButton_Click_1(object sender, EventArgs e)
        {
            // This calls the method to clear data within these methods
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();
        }
    }
}
