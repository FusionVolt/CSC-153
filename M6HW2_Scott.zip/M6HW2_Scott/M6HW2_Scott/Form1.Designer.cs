﻿namespace M6HW2_Scott
{
    partial class automotiveForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.oilLubeGroupBox = new System.Windows.Forms.GroupBox();
            this.lubeCheckBox = new System.Windows.Forms.CheckBox();
            this.oilCheckBox = new System.Windows.Forms.CheckBox();
            this.flushesGroupBox = new System.Windows.Forms.GroupBox();
            this.TransmissionCheckBox = new System.Windows.Forms.CheckBox();
            this.radiatorCheckBox = new System.Windows.Forms.CheckBox();
            this.miscGroupBox = new System.Windows.Forms.GroupBox();
            this.TireCheckBox = new System.Windows.Forms.CheckBox();
            this.MufflerCheckBox = new System.Windows.Forms.CheckBox();
            this.InspectionCheckBox = new System.Windows.Forms.CheckBox();
            this.partsLaborGroupBox = new System.Windows.Forms.GroupBox();
            this.laborTextBox = new System.Windows.Forms.TextBox();
            this.laborLabel = new System.Windows.Forms.Label();
            this.partLabel = new System.Windows.Forms.Label();
            this.partsTextBox = new System.Windows.Forms.TextBox();
            this.summaryGroupBox5 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.totalFeesLabel = new System.Windows.Forms.Label();
            this.taxLabel = new System.Windows.Forms.Label();
            this.partsLabel = new System.Windows.Forms.Label();
            this.serviceLaborLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.oilLubeGroupBox.SuspendLayout();
            this.flushesGroupBox.SuspendLayout();
            this.miscGroupBox.SuspendLayout();
            this.partsLaborGroupBox.SuspendLayout();
            this.summaryGroupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // oilLubeGroupBox
            // 
            this.oilLubeGroupBox.BackColor = System.Drawing.SystemColors.Highlight;
            this.oilLubeGroupBox.Controls.Add(this.lubeCheckBox);
            this.oilLubeGroupBox.Controls.Add(this.oilCheckBox);
            this.oilLubeGroupBox.Location = new System.Drawing.Point(12, 12);
            this.oilLubeGroupBox.Name = "oilLubeGroupBox";
            this.oilLubeGroupBox.Size = new System.Drawing.Size(200, 80);
            this.oilLubeGroupBox.TabIndex = 0;
            this.oilLubeGroupBox.TabStop = false;
            this.oilLubeGroupBox.Text = "Oil and Lube";
            // 
            // lubeCheckBox
            // 
            this.lubeCheckBox.AutoSize = true;
            this.lubeCheckBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lubeCheckBox.Location = new System.Drawing.Point(6, 44);
            this.lubeCheckBox.Name = "lubeCheckBox";
            this.lubeCheckBox.Size = new System.Drawing.Size(119, 19);
            this.lubeCheckBox.TabIndex = 9;
            this.lubeCheckBox.Text = "Lube Job ($18.00)";
            this.lubeCheckBox.UseVisualStyleBackColor = true;
            // 
            // oilCheckBox
            // 
            this.oilCheckBox.AutoSize = true;
            this.oilCheckBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oilCheckBox.Location = new System.Drawing.Point(6, 19);
            this.oilCheckBox.Name = "oilCheckBox";
            this.oilCheckBox.Size = new System.Drawing.Size(129, 19);
            this.oilCheckBox.TabIndex = 8;
            this.oilCheckBox.Text = "Oil Change ($26.00)";
            this.oilCheckBox.UseVisualStyleBackColor = true;
            // 
            // flushesGroupBox
            // 
            this.flushesGroupBox.Controls.Add(this.TransmissionCheckBox);
            this.flushesGroupBox.Controls.Add(this.radiatorCheckBox);
            this.flushesGroupBox.Location = new System.Drawing.Point(228, 12);
            this.flushesGroupBox.Name = "flushesGroupBox";
            this.flushesGroupBox.Size = new System.Drawing.Size(200, 80);
            this.flushesGroupBox.TabIndex = 0;
            this.flushesGroupBox.TabStop = false;
            this.flushesGroupBox.Text = "Flushes";
            // 
            // TransmissionCheckBox
            // 
            this.TransmissionCheckBox.AutoSize = true;
            this.TransmissionCheckBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TransmissionCheckBox.Location = new System.Drawing.Point(6, 44);
            this.TransmissionCheckBox.Name = "TransmissionCheckBox";
            this.TransmissionCheckBox.Size = new System.Drawing.Size(175, 19);
            this.TransmissionCheckBox.TabIndex = 10;
            this.TransmissionCheckBox.Text = "Transmission Flush ($80.00)";
            this.TransmissionCheckBox.UseVisualStyleBackColor = true;
            // 
            // radiatorCheckBox
            // 
            this.radiatorCheckBox.AutoSize = true;
            this.radiatorCheckBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiatorCheckBox.Location = new System.Drawing.Point(6, 19);
            this.radiatorCheckBox.Name = "radiatorCheckBox";
            this.radiatorCheckBox.Size = new System.Drawing.Size(148, 19);
            this.radiatorCheckBox.TabIndex = 9;
            this.radiatorCheckBox.Text = "Radiator Flush ($30.00)";
            this.radiatorCheckBox.UseVisualStyleBackColor = true;
            // 
            // miscGroupBox
            // 
            this.miscGroupBox.Controls.Add(this.TireCheckBox);
            this.miscGroupBox.Controls.Add(this.MufflerCheckBox);
            this.miscGroupBox.Controls.Add(this.InspectionCheckBox);
            this.miscGroupBox.Location = new System.Drawing.Point(12, 111);
            this.miscGroupBox.Name = "miscGroupBox";
            this.miscGroupBox.Size = new System.Drawing.Size(200, 100);
            this.miscGroupBox.TabIndex = 0;
            this.miscGroupBox.TabStop = false;
            this.miscGroupBox.Text = "Misc";
            // 
            // TireCheckBox
            // 
            this.TireCheckBox.AutoSize = true;
            this.TireCheckBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TireCheckBox.Location = new System.Drawing.Point(6, 73);
            this.TireCheckBox.Name = "TireCheckBox";
            this.TireCheckBox.Size = new System.Drawing.Size(140, 19);
            this.TireCheckBox.TabIndex = 11;
            this.TireCheckBox.Text = "Tire Rotation ($20.00)";
            this.TireCheckBox.UseVisualStyleBackColor = true;
            // 
            // MufflerCheckBox
            // 
            this.MufflerCheckBox.AutoSize = true;
            this.MufflerCheckBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MufflerCheckBox.Location = new System.Drawing.Point(6, 48);
            this.MufflerCheckBox.Name = "MufflerCheckBox";
            this.MufflerCheckBox.Size = new System.Drawing.Size(161, 19);
            this.MufflerCheckBox.TabIndex = 10;
            this.MufflerCheckBox.Text = "Replace Muffler ($100.00)";
            this.MufflerCheckBox.UseVisualStyleBackColor = true;
            // 
            // InspectionCheckBox
            // 
            this.InspectionCheckBox.AutoSize = true;
            this.InspectionCheckBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InspectionCheckBox.Location = new System.Drawing.Point(6, 23);
            this.InspectionCheckBox.Name = "InspectionCheckBox";
            this.InspectionCheckBox.Size = new System.Drawing.Size(127, 19);
            this.InspectionCheckBox.TabIndex = 9;
            this.InspectionCheckBox.Text = "Inspection ($15.00)";
            this.InspectionCheckBox.UseVisualStyleBackColor = true;
            // 
            // partsLaborGroupBox
            // 
            this.partsLaborGroupBox.Controls.Add(this.laborTextBox);
            this.partsLaborGroupBox.Controls.Add(this.laborLabel);
            this.partsLaborGroupBox.Controls.Add(this.partLabel);
            this.partsLaborGroupBox.Controls.Add(this.partsTextBox);
            this.partsLaborGroupBox.Location = new System.Drawing.Point(228, 111);
            this.partsLaborGroupBox.Name = "partsLaborGroupBox";
            this.partsLaborGroupBox.Size = new System.Drawing.Size(200, 100);
            this.partsLaborGroupBox.TabIndex = 0;
            this.partsLaborGroupBox.TabStop = false;
            this.partsLaborGroupBox.Text = "Parts and Labor";
            // 
            // laborTextBox
            // 
            this.laborTextBox.Location = new System.Drawing.Point(90, 46);
            this.laborTextBox.Name = "laborTextBox";
            this.laborTextBox.Size = new System.Drawing.Size(58, 20);
            this.laborTextBox.TabIndex = 11;
            // 
            // laborLabel
            // 
            this.laborLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laborLabel.Location = new System.Drawing.Point(19, 44);
            this.laborLabel.Name = "laborLabel";
            this.laborLabel.Size = new System.Drawing.Size(56, 23);
            this.laborLabel.TabIndex = 10;
            this.laborLabel.Text = "Labor ($)";
            this.laborLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // partLabel
            // 
            this.partLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.partLabel.Location = new System.Drawing.Point(32, 17);
            this.partLabel.Name = "partLabel";
            this.partLabel.Size = new System.Drawing.Size(43, 23);
            this.partLabel.TabIndex = 9;
            this.partLabel.Text = "Parts";
            this.partLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // partsTextBox
            // 
            this.partsTextBox.Location = new System.Drawing.Point(90, 20);
            this.partsTextBox.Name = "partsTextBox";
            this.partsTextBox.Size = new System.Drawing.Size(58, 20);
            this.partsTextBox.TabIndex = 8;
            // 
            // summaryGroupBox5
            // 
            this.summaryGroupBox5.Controls.Add(this.label8);
            this.summaryGroupBox5.Controls.Add(this.label7);
            this.summaryGroupBox5.Controls.Add(this.label6);
            this.summaryGroupBox5.Controls.Add(this.label5);
            this.summaryGroupBox5.Controls.Add(this.totalFeesLabel);
            this.summaryGroupBox5.Controls.Add(this.taxLabel);
            this.summaryGroupBox5.Controls.Add(this.partsLabel);
            this.summaryGroupBox5.Controls.Add(this.serviceLaborLabel);
            this.summaryGroupBox5.Location = new System.Drawing.Point(12, 232);
            this.summaryGroupBox5.Name = "summaryGroupBox5";
            this.summaryGroupBox5.Size = new System.Drawing.Size(416, 171);
            this.summaryGroupBox5.TabIndex = 1;
            this.summaryGroupBox5.TabStop = false;
            this.summaryGroupBox5.Text = "Summary";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(28, 135);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 23);
            this.label8.TabIndex = 7;
            this.label8.Text = "Total Fees";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(28, 97);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(113, 23);
            this.label7.TabIndex = 6;
            this.label7.Text = "Tax (on parts)";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(28, 65);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 23);
            this.label6.TabIndex = 5;
            this.label6.Text = "Parts";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(28, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 23);
            this.label5.TabIndex = 4;
            this.label5.Text = "Service and Labor";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // totalFeesLabel
            // 
            this.totalFeesLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalFeesLabel.Location = new System.Drawing.Point(163, 135);
            this.totalFeesLabel.Name = "totalFeesLabel";
            this.totalFeesLabel.Size = new System.Drawing.Size(100, 23);
            this.totalFeesLabel.TabIndex = 3;
            this.totalFeesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // taxLabel
            // 
            this.taxLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.taxLabel.Location = new System.Drawing.Point(163, 97);
            this.taxLabel.Name = "taxLabel";
            this.taxLabel.Size = new System.Drawing.Size(100, 23);
            this.taxLabel.TabIndex = 2;
            this.taxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // partsLabel
            // 
            this.partsLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.partsLabel.Location = new System.Drawing.Point(163, 65);
            this.partsLabel.Name = "partsLabel";
            this.partsLabel.Size = new System.Drawing.Size(100, 23);
            this.partsLabel.TabIndex = 1;
            this.partsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // serviceLaborLabel
            // 
            this.serviceLaborLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.serviceLaborLabel.Location = new System.Drawing.Point(163, 26);
            this.serviceLaborLabel.Name = "serviceLaborLabel";
            this.serviceLaborLabel.Size = new System.Drawing.Size(100, 23);
            this.serviceLaborLabel.TabIndex = 0;
            this.serviceLaborLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calculateButton
            // 
            this.calculateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculateButton.Location = new System.Drawing.Point(83, 414);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 2;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click_1);
            // 
            // ClearButton
            // 
            this.ClearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearButton.Location = new System.Drawing.Point(175, 414);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(75, 23);
            this.ClearButton.TabIndex = 3;
            this.ClearButton.Text = "Clear";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click_1);
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton.Location = new System.Drawing.Point(263, 414);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(75, 23);
            this.ExitButton.TabIndex = 4;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // automotiveForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(450, 449);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.summaryGroupBox5);
            this.Controls.Add(this.partsLaborGroupBox);
            this.Controls.Add(this.miscGroupBox);
            this.Controls.Add(this.flushesGroupBox);
            this.Controls.Add(this.oilLubeGroupBox);
            this.Name = "automotiveForm";
            this.Text = "Automotive";
            this.oilLubeGroupBox.ResumeLayout(false);
            this.oilLubeGroupBox.PerformLayout();
            this.flushesGroupBox.ResumeLayout(false);
            this.flushesGroupBox.PerformLayout();
            this.miscGroupBox.ResumeLayout(false);
            this.miscGroupBox.PerformLayout();
            this.partsLaborGroupBox.ResumeLayout(false);
            this.partsLaborGroupBox.PerformLayout();
            this.summaryGroupBox5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox oilLubeGroupBox;
        private System.Windows.Forms.CheckBox lubeCheckBox;
        private System.Windows.Forms.CheckBox oilCheckBox;
        private System.Windows.Forms.GroupBox flushesGroupBox;
        private System.Windows.Forms.CheckBox TransmissionCheckBox;
        private System.Windows.Forms.CheckBox radiatorCheckBox;
        private System.Windows.Forms.GroupBox miscGroupBox;
        private System.Windows.Forms.CheckBox TireCheckBox;
        private System.Windows.Forms.CheckBox MufflerCheckBox;
        private System.Windows.Forms.CheckBox InspectionCheckBox;
        private System.Windows.Forms.GroupBox partsLaborGroupBox;
        private System.Windows.Forms.TextBox laborTextBox;
        private System.Windows.Forms.Label laborLabel;
        private System.Windows.Forms.Label partLabel;
        private System.Windows.Forms.TextBox partsTextBox;
        private System.Windows.Forms.GroupBox summaryGroupBox5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label totalFeesLabel;
        private System.Windows.Forms.Label taxLabel;
        private System.Windows.Forms.Label partsLabel;
        private System.Windows.Forms.Label serviceLaborLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Button ExitButton;
    }
}

