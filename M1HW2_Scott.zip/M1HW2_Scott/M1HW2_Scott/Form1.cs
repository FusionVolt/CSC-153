﻿/**
* 01/29/2017
* CSC 153
* Cameron Scott
* This Program Identifies the name of the cards
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW2_Scott
{
    public partial class CardIdentifierForm : Form
    {
        public CardIdentifierForm()
        {
            InitializeComponent();
        }

        private void acespades_Click(object sender, EventArgs e)
        {
            cardNameTexbox.Text= "Ace Of Spades";
        }

        private void jackclover_Click(object sender, EventArgs e)
        {
            cardNameTexbox.Text = "Jack of Clover";
        }

        private void kingHearts_Click(object sender, EventArgs e)
        {
            cardNameTexbox.Text = "King of Hearts";
        }

        private void Joker_Click(object sender, EventArgs e)
        {
            cardNameTexbox.Text = "Joker or Wild card";
        }

        private void sevenDiamonds_Click(object sender, EventArgs e)
        {
            cardNameTexbox.Text = "Seven of Diamond";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
