﻿namespace M1HW2_Scott
{
    partial class CardIdentifierForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sevenDiamonds = new System.Windows.Forms.PictureBox();
            this.Joker = new System.Windows.Forms.PictureBox();
            this.kingHearts = new System.Windows.Forms.PictureBox();
            this.jackclover = new System.Windows.Forms.PictureBox();
            this.acespades = new System.Windows.Forms.PictureBox();
            this.identifierLabel = new System.Windows.Forms.Label();
            this.cardNameTexbox = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.sevenDiamonds)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Joker)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingHearts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jackclover)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.acespades)).BeginInit();
            this.SuspendLayout();
            // 
            // sevenDiamonds
            // 
            this.sevenDiamonds.Image = global::M1HW2_Scott.Properties.Resources._7_of_diamonds_by_farvei_d3kgfgv;
            this.sevenDiamonds.Location = new System.Drawing.Point(548, 74);
            this.sevenDiamonds.MaximumSize = new System.Drawing.Size(100, 100);
            this.sevenDiamonds.MinimumSize = new System.Drawing.Size(50, 50);
            this.sevenDiamonds.Name = "sevenDiamonds";
            this.sevenDiamonds.Size = new System.Drawing.Size(100, 100);
            this.sevenDiamonds.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sevenDiamonds.TabIndex = 4;
            this.sevenDiamonds.TabStop = false;
            this.sevenDiamonds.Click += new System.EventHandler(this.sevenDiamonds_Click);
            // 
            // Joker
            // 
            this.Joker.Image = global::M1HW2_Scott.Properties.Resources._8iGb9AKrT;
            this.Joker.Location = new System.Drawing.Point(413, 74);
            this.Joker.MaximumSize = new System.Drawing.Size(100, 100);
            this.Joker.MinimumSize = new System.Drawing.Size(50, 50);
            this.Joker.Name = "Joker";
            this.Joker.Size = new System.Drawing.Size(100, 100);
            this.Joker.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Joker.TabIndex = 3;
            this.Joker.TabStop = false;
            this.Joker.Click += new System.EventHandler(this.Joker_Click);
            // 
            // kingHearts
            // 
            this.kingHearts.Image = global::M1HW2_Scott.Properties.Resources.raf_750x1000_075_t_e0e1dd_064437a66d_u5;
            this.kingHearts.Location = new System.Drawing.Point(284, 74);
            this.kingHearts.MaximumSize = new System.Drawing.Size(100, 100);
            this.kingHearts.MinimumSize = new System.Drawing.Size(50, 50);
            this.kingHearts.Name = "kingHearts";
            this.kingHearts.Size = new System.Drawing.Size(100, 100);
            this.kingHearts.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.kingHearts.TabIndex = 2;
            this.kingHearts.TabStop = false;
            this.kingHearts.Click += new System.EventHandler(this.kingHearts_Click);
            // 
            // jackclover
            // 
            this.jackclover.Image = global::M1HW2_Scott.Properties.Resources._8e33e47866c72daa58eff9db08c4f7bb__mormont_game_of_thrones_game_cards;
            this.jackclover.Location = new System.Drawing.Point(154, 74);
            this.jackclover.MaximumSize = new System.Drawing.Size(100, 100);
            this.jackclover.MinimumSize = new System.Drawing.Size(50, 50);
            this.jackclover.Name = "jackclover";
            this.jackclover.Size = new System.Drawing.Size(100, 100);
            this.jackclover.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.jackclover.TabIndex = 1;
            this.jackclover.TabStop = false;
            this.jackclover.Click += new System.EventHandler(this.jackclover_Click);
            // 
            // acespades
            // 
            this.acespades.Image = global::M1HW2_Scott.Properties.Resources.Ace_Spades;
            this.acespades.Location = new System.Drawing.Point(34, 74);
            this.acespades.MaximumSize = new System.Drawing.Size(100, 100);
            this.acespades.MinimumSize = new System.Drawing.Size(50, 50);
            this.acespades.Name = "acespades";
            this.acespades.Size = new System.Drawing.Size(100, 100);
            this.acespades.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.acespades.TabIndex = 0;
            this.acespades.TabStop = false;
            this.acespades.Click += new System.EventHandler(this.acespades_Click);
            // 
            // identifierLabel
            // 
            this.identifierLabel.Location = new System.Drawing.Point(255, 37);
            this.identifierLabel.Name = "identifierLabel";
            this.identifierLabel.Size = new System.Drawing.Size(179, 23);
            this.identifierLabel.TabIndex = 5;
            this.identifierLabel.Text = "Click a Card to see its Name";
            // 
            // cardNameTexbox
            // 
            this.cardNameTexbox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cardNameTexbox.Location = new System.Drawing.Point(154, 193);
            this.cardNameTexbox.Name = "cardNameTexbox";
            this.cardNameTexbox.Size = new System.Drawing.Size(359, 26);
            this.cardNameTexbox.TabIndex = 6;
            this.cardNameTexbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(284, 227);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(100, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // CardIdentifierForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(699, 262);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.cardNameTexbox);
            this.Controls.Add(this.identifierLabel);
            this.Controls.Add(this.sevenDiamonds);
            this.Controls.Add(this.Joker);
            this.Controls.Add(this.kingHearts);
            this.Controls.Add(this.jackclover);
            this.Controls.Add(this.acespades);
            this.Name = "CardIdentifierForm";
            this.Text = "Card Identifier";
            ((System.ComponentModel.ISupportInitialize)(this.sevenDiamonds)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Joker)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingHearts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jackclover)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.acespades)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox acespades;
        private System.Windows.Forms.PictureBox jackclover;
        private System.Windows.Forms.PictureBox kingHearts;
        private System.Windows.Forms.PictureBox Joker;
        private System.Windows.Forms.PictureBox sevenDiamonds;
        private System.Windows.Forms.Label identifierLabel;
        private System.Windows.Forms.TextBox cardNameTexbox;
        private System.Windows.Forms.Button exitButton;
    }
}

