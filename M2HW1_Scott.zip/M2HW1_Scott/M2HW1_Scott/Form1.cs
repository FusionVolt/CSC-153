﻿/**
* 03/14/2018
* CSC 153
* Cameron Scott
* This program does different formats for names
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW1_Scott
{
    public partial class Name_Formatter : Form
    {
        // Private strings holds the variables for future use
        private string title;
        private string firstName;
        private string middleName;
        private string lastName;
        public Name_Formatter()
        {
            InitializeComponent();
        }

        private void nameFormatButton_Click(object sender, EventArgs e)
        {
         // This formats the Full name. 
            
            title = titleTextBox.Text;
            firstName = firstTextBox.Text;
            middleName = middleTextBox.Text;
            lastName = lastTextBox.Text;
            resultsLabel.Text = title + " " + firstName + " " + middleName + " " + lastName;
        }

        private void lastFirstFormatButton_Click(object sender, EventArgs e)
        // This formats the results label from the order to  last and first name.
        {
            firstName = firstTextBox.Text;
            lastName = lastTextBox.Text;
            resultsLabel.Text = lastName + ", " + firstName;
        }

        private void firstLastFormatButton_Click(object sender, EventArgs e)
        // This formats the results label from the order to  first and last name.
        {
            firstName = firstTextBox.Text;
            lastName = lastTextBox.Text;
            resultsLabel.Text = firstName + " " + lastName;
        }

        private void lastFirMidFormatButton_Click(object sender, EventArgs e)
        // This formats the results label from the order to  last, first and middle name.
        {
            firstName = firstTextBox.Text;
            middleName = middleTextBox.Text;
            lastName = lastTextBox.Text;
            resultsLabel.Text = lastName + ", " + firstName + " " + middleName;
        }

        private void lastFirMidTitleNameFormatButton_Click(object sender, EventArgs e)
        // This formats the results label from the order to  last, first, and Middle name, and title.
        {
            title = titleTextBox.Text;
            firstName = firstTextBox.Text;
            middleName = middleTextBox.Text;
            lastName = lastTextBox.Text;
            resultsLabel.Text = lastName + ", " + firstName + " " + middleName + ", " + title;
        }

        private void firstMidLastNameFromatButton_Click_1(object sender, EventArgs e)
        // This formats the results label from the order to first, middle, and last name.
        {
            firstName = firstTextBox.Text;
            middleName = middleTextBox.Text;
            lastName = lastTextBox.Text;
            resultsLabel.Text = firstName + " " + middleName + " " + lastName;
        }

        private void resetButton_Click(object sender, EventArgs e)
            // This clears everything.
        {
            firstTextBox.Text = "";
            middleTextBox.Text = "";
            lastTextBox.Text = "";
            titleTextBox.Text = "";
            resultsLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        // This closes the program.
        { 
            this.Close();
        }
    }
}
