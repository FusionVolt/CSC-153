﻿namespace M2HW1_Scott
{
    partial class Name_Formatter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.informationLabel = new System.Windows.Forms.Label();
            this.firstLabel = new System.Windows.Forms.Label();
            this.middleLabel = new System.Windows.Forms.Label();
            this.lastLabel = new System.Windows.Forms.Label();
            this.firstTextBox = new System.Windows.Forms.TextBox();
            this.middleTextBox = new System.Windows.Forms.TextBox();
            this.lastTextBox = new System.Windows.Forms.TextBox();
            this.titleLabel = new System.Windows.Forms.Label();
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.resultsLabel = new System.Windows.Forms.Label();
            this.resetButton = new System.Windows.Forms.Button();
            this.nameFormatButton = new System.Windows.Forms.Button();
            this.firstMidLastNameFromatButton = new System.Windows.Forms.Button();
            this.lastFirstFormatButton = new System.Windows.Forms.Button();
            this.firstLastFormatButton = new System.Windows.Forms.Button();
            this.lastFirMidTitleNameFormatButton = new System.Windows.Forms.Button();
            this.lastFirMidFormatButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // informationLabel
            // 
            this.informationLabel.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.informationLabel.Location = new System.Drawing.Point(123, 9);
            this.informationLabel.Name = "informationLabel";
            this.informationLabel.Size = new System.Drawing.Size(219, 25);
            this.informationLabel.TabIndex = 0;
            this.informationLabel.Text = "Enter your information";
            this.informationLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // firstLabel
            // 
            this.firstLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.firstLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstLabel.Location = new System.Drawing.Point(87, 54);
            this.firstLabel.Name = "firstLabel";
            this.firstLabel.Size = new System.Drawing.Size(92, 26);
            this.firstLabel.TabIndex = 1;
            this.firstLabel.Text = "First Name:";
            this.firstLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // middleLabel
            // 
            this.middleLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.middleLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.middleLabel.Location = new System.Drawing.Point(87, 95);
            this.middleLabel.Name = "middleLabel";
            this.middleLabel.Size = new System.Drawing.Size(101, 24);
            this.middleLabel.TabIndex = 2;
            this.middleLabel.Text = "Middle Name:";
            this.middleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lastLabel
            // 
            this.lastLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lastLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastLabel.Location = new System.Drawing.Point(87, 135);
            this.lastLabel.Name = "lastLabel";
            this.lastLabel.Size = new System.Drawing.Size(92, 24);
            this.lastLabel.TabIndex = 3;
            this.lastLabel.Text = "Last Name:";
            this.lastLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // firstTextBox
            // 
            this.firstTextBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstTextBox.Location = new System.Drawing.Point(213, 54);
            this.firstTextBox.Name = "firstTextBox";
            this.firstTextBox.Size = new System.Drawing.Size(179, 26);
            this.firstTextBox.TabIndex = 4;
            // 
            // middleTextBox
            // 
            this.middleTextBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.middleTextBox.Location = new System.Drawing.Point(213, 93);
            this.middleTextBox.Name = "middleTextBox";
            this.middleTextBox.Size = new System.Drawing.Size(179, 26);
            this.middleTextBox.TabIndex = 5;
            // 
            // lastTextBox
            // 
            this.lastTextBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastTextBox.Location = new System.Drawing.Point(213, 133);
            this.lastTextBox.Name = "lastTextBox";
            this.lastTextBox.Size = new System.Drawing.Size(179, 26);
            this.lastTextBox.TabIndex = 6;
            // 
            // titleLabel
            // 
            this.titleLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.titleLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(87, 177);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(79, 24);
            this.titleLabel.TabIndex = 7;
            this.titleLabel.Text = "Title:";
            this.titleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // titleTextBox
            // 
            this.titleTextBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleTextBox.Location = new System.Drawing.Point(213, 175);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new System.Drawing.Size(179, 26);
            this.titleTextBox.TabIndex = 8;
            // 
            // resultsLabel
            // 
            this.resultsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.resultsLabel.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultsLabel.Location = new System.Drawing.Point(27, 212);
            this.resultsLabel.Name = "resultsLabel";
            this.resultsLabel.Size = new System.Drawing.Size(426, 24);
            this.resultsLabel.TabIndex = 9;
            this.resultsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // resetButton
            // 
            this.resetButton.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resetButton.Location = new System.Drawing.Point(140, 376);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(79, 23);
            this.resetButton.TabIndex = 11;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // nameFormatButton
            // 
            this.nameFormatButton.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameFormatButton.Location = new System.Drawing.Point(71, 264);
            this.nameFormatButton.Name = "nameFormatButton";
            this.nameFormatButton.Size = new System.Drawing.Size(148, 23);
            this.nameFormatButton.TabIndex = 12;
            this.nameFormatButton.Text = "Title First Middle Last";
            this.nameFormatButton.UseVisualStyleBackColor = true;
            this.nameFormatButton.Click += new System.EventHandler(this.nameFormatButton_Click);
            // 
            // firstMidLastNameFromatButton
            // 
            this.firstMidLastNameFromatButton.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstMidLastNameFromatButton.Location = new System.Drawing.Point(71, 293);
            this.firstMidLastNameFromatButton.Name = "firstMidLastNameFromatButton";
            this.firstMidLastNameFromatButton.Size = new System.Drawing.Size(148, 23);
            this.firstMidLastNameFromatButton.TabIndex = 13;
            this.firstMidLastNameFromatButton.Text = "First Middle Last";
            this.firstMidLastNameFromatButton.UseVisualStyleBackColor = true;
            this.firstMidLastNameFromatButton.Click += new System.EventHandler(this.firstMidLastNameFromatButton_Click_1);
            // 
            // lastFirstFormatButton
            // 
            this.lastFirstFormatButton.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastFirstFormatButton.Location = new System.Drawing.Point(249, 322);
            this.lastFirstFormatButton.Name = "lastFirstFormatButton";
            this.lastFirstFormatButton.Size = new System.Drawing.Size(148, 23);
            this.lastFirstFormatButton.TabIndex = 14;
            this.lastFirstFormatButton.Text = "Last First";
            this.lastFirstFormatButton.UseVisualStyleBackColor = true;
            this.lastFirstFormatButton.Click += new System.EventHandler(this.lastFirstFormatButton_Click);
            // 
            // firstLastFormatButton
            // 
            this.firstLastFormatButton.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstLastFormatButton.Location = new System.Drawing.Point(71, 322);
            this.firstLastFormatButton.Name = "firstLastFormatButton";
            this.firstLastFormatButton.Size = new System.Drawing.Size(148, 23);
            this.firstLastFormatButton.TabIndex = 15;
            this.firstLastFormatButton.Text = "First Last";
            this.firstLastFormatButton.UseVisualStyleBackColor = true;
            this.firstLastFormatButton.Click += new System.EventHandler(this.firstLastFormatButton_Click);
            // 
            // lastFirMidTitleNameFormatButton
            // 
            this.lastFirMidTitleNameFormatButton.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastFirMidTitleNameFormatButton.Location = new System.Drawing.Point(249, 264);
            this.lastFirMidTitleNameFormatButton.Name = "lastFirMidTitleNameFormatButton";
            this.lastFirMidTitleNameFormatButton.Size = new System.Drawing.Size(148, 23);
            this.lastFirMidTitleNameFormatButton.TabIndex = 16;
            this.lastFirMidTitleNameFormatButton.Text = "Last First Middle Title";
            this.lastFirMidTitleNameFormatButton.UseVisualStyleBackColor = true;
            this.lastFirMidTitleNameFormatButton.Click += new System.EventHandler(this.lastFirMidTitleNameFormatButton_Click);
            // 
            // lastFirMidFormatButton
            // 
            this.lastFirMidFormatButton.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastFirMidFormatButton.Location = new System.Drawing.Point(249, 293);
            this.lastFirMidFormatButton.Name = "lastFirMidFormatButton";
            this.lastFirMidFormatButton.Size = new System.Drawing.Size(148, 23);
            this.lastFirMidFormatButton.TabIndex = 17;
            this.lastFirMidFormatButton.Text = "Last First Middle";
            this.lastFirMidFormatButton.UseVisualStyleBackColor = true;
            this.lastFirMidFormatButton.Click += new System.EventHandler(this.lastFirMidFormatButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(253, 376);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(79, 23);
            this.exitButton.TabIndex = 18;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Name_Formatter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(475, 418);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.lastFirMidFormatButton);
            this.Controls.Add(this.lastFirMidTitleNameFormatButton);
            this.Controls.Add(this.firstLastFormatButton);
            this.Controls.Add(this.lastFirstFormatButton);
            this.Controls.Add(this.firstMidLastNameFromatButton);
            this.Controls.Add(this.nameFormatButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.resultsLabel);
            this.Controls.Add(this.titleTextBox);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.lastTextBox);
            this.Controls.Add(this.middleTextBox);
            this.Controls.Add(this.firstTextBox);
            this.Controls.Add(this.lastLabel);
            this.Controls.Add(this.middleLabel);
            this.Controls.Add(this.firstLabel);
            this.Controls.Add(this.informationLabel);
            this.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Name_Formatter";
            this.Text = "Name Formatter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label informationLabel;
        private System.Windows.Forms.Label firstLabel;
        private System.Windows.Forms.Label middleLabel;
        private System.Windows.Forms.Label lastLabel;
        private System.Windows.Forms.TextBox firstTextBox;
        private System.Windows.Forms.TextBox middleTextBox;
        private System.Windows.Forms.TextBox lastTextBox;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.TextBox titleTextBox;
        private System.Windows.Forms.Label resultsLabel;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button nameFormatButton;
        private System.Windows.Forms.Button firstMidLastNameFromatButton;
        private System.Windows.Forms.Button lastFirstFormatButton;
        private System.Windows.Forms.Button firstLastFormatButton;
        private System.Windows.Forms.Button lastFirMidTitleNameFormatButton;
        private System.Windows.Forms.Button lastFirMidFormatButton;
        private System.Windows.Forms.Button exitButton;
    }
}

