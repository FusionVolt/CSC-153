﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Go to class properties (C#) and set output type to Windows Application
// then add new item (class) and name it "Program.cs"

namespace Ch9PP1_Scott
{
    public class Pet
    {
        // Fields
        private string _name;       // The Name property holds the name of a pet
        private string _type;       // The type of animal (Dog, Cat, or Bird) that this pet is.
        private int _age;           // The pet's age

        // Constructor
        public Pet()
        {
            _name = name;
            _type = type;
            _age = 0;
        }

        // Name property
        public string name
        {
            get { return _name; }
            set { _name = value; }
        } 

        // Type property
        public string type
        {
            get { return _type; }
            set { _type = value; }
        }
        
        // Age property
        public int age
        {
            get { return _age; }
            set { _age = value; }
        }

        
    }
}
