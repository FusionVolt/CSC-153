﻿/**
* 05/11/2018
* CSC 153
* Cameron Scott
* This program retrieves the name, type, and age of your pet via use of class
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ch9PP1_Scott;

namespace Ch9PP1_Scott
{
    public partial class Form1 : Form
    {
        // "Pet" is the object pulled from a class
        Pet _pet = new Pet();
        public Form1()
        {
            InitializeComponent();
        }

        private void retrieveInfoButton_Click(object sender, EventArgs e)
        {
            try
            {
                // .name, .type and .age are variables being used from a class under pet.
                _pet.name = petNameTextBox.Text;
                _pet.type = petTypeTextBox.Text;
                _pet.age = int.Parse(petAgeTextBox.Text);

                petInformationLabel.Text = "Name: " + _pet.name + "  \nType:\t " + _pet.type + "\nAge: " + _pet.age;
            }
            catch(Exception)
            {

                MessageBox.Show("The field 'Age of pet' requires an number");
            }
            
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            petNameTextBox.Text = "";
            petTypeTextBox.Text = "";
            petAgeTextBox.Text = "";
            petInformationLabel.Text = "";
            petNameTextBox.Focus();
        }

        private void Exitbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
