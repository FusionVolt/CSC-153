﻿namespace Ch9PP1_Scott
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.petNameLabel = new System.Windows.Forms.Label();
            this.petTypeLabel = new System.Windows.Forms.Label();
            this.petAgeLabel = new System.Windows.Forms.Label();
            this.petInformationLabel = new System.Windows.Forms.Label();
            this.retrieveInfoButton = new System.Windows.Forms.Button();
            this.petNameTextBox = new System.Windows.Forms.TextBox();
            this.petTypeTextBox = new System.Windows.Forms.TextBox();
            this.petAgeTextBox = new System.Windows.Forms.TextBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.Exitbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // petNameLabel
            // 
            this.petNameLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.petNameLabel.Location = new System.Drawing.Point(3, 41);
            this.petNameLabel.Name = "petNameLabel";
            this.petNameLabel.Size = new System.Drawing.Size(100, 23);
            this.petNameLabel.TabIndex = 0;
            this.petNameLabel.Text = "Name of pet:";
            this.petNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // petTypeLabel
            // 
            this.petTypeLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.petTypeLabel.Location = new System.Drawing.Point(3, 75);
            this.petTypeLabel.Name = "petTypeLabel";
            this.petTypeLabel.Size = new System.Drawing.Size(100, 23);
            this.petTypeLabel.TabIndex = 1;
            this.petTypeLabel.Text = "Type of pet:";
            this.petTypeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // petAgeLabel
            // 
            this.petAgeLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.petAgeLabel.Location = new System.Drawing.Point(3, 109);
            this.petAgeLabel.Name = "petAgeLabel";
            this.petAgeLabel.Size = new System.Drawing.Size(100, 23);
            this.petAgeLabel.TabIndex = 2;
            this.petAgeLabel.Text = "Age of pet:";
            this.petAgeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // petInformationLabel
            // 
            this.petInformationLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.petInformationLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.petInformationLabel.Location = new System.Drawing.Point(102, 145);
            this.petInformationLabel.Name = "petInformationLabel";
            this.petInformationLabel.Size = new System.Drawing.Size(142, 53);
            this.petInformationLabel.TabIndex = 3;
            this.petInformationLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // retrieveInfoButton
            // 
            this.retrieveInfoButton.Location = new System.Drawing.Point(37, 208);
            this.retrieveInfoButton.Name = "retrieveInfoButton";
            this.retrieveInfoButton.Size = new System.Drawing.Size(75, 42);
            this.retrieveInfoButton.TabIndex = 4;
            this.retrieveInfoButton.Text = "Retrieve Information";
            this.retrieveInfoButton.UseVisualStyleBackColor = true;
            this.retrieveInfoButton.Click += new System.EventHandler(this.retrieveInfoButton_Click);
            // 
            // petNameTextBox
            // 
            this.petNameTextBox.Location = new System.Drawing.Point(123, 41);
            this.petNameTextBox.Name = "petNameTextBox";
            this.petNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.petNameTextBox.TabIndex = 1;
            // 
            // petTypeTextBox
            // 
            this.petTypeTextBox.Location = new System.Drawing.Point(123, 78);
            this.petTypeTextBox.Name = "petTypeTextBox";
            this.petTypeTextBox.Size = new System.Drawing.Size(100, 20);
            this.petTypeTextBox.TabIndex = 2;
            // 
            // petAgeTextBox
            // 
            this.petAgeTextBox.Location = new System.Drawing.Point(123, 111);
            this.petAgeTextBox.Name = "petAgeTextBox";
            this.petAgeTextBox.Size = new System.Drawing.Size(100, 20);
            this.petAgeTextBox.TabIndex = 3;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(132, 208);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 42);
            this.clearButton.TabIndex = 5;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Exitbutton
            // 
            this.Exitbutton.Location = new System.Drawing.Point(227, 208);
            this.Exitbutton.Name = "Exitbutton";
            this.Exitbutton.Size = new System.Drawing.Size(75, 42);
            this.Exitbutton.TabIndex = 6;
            this.Exitbutton.Text = "Exit";
            this.Exitbutton.UseVisualStyleBackColor = true;
            this.Exitbutton.Click += new System.EventHandler(this.Exitbutton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(314, 262);
            this.Controls.Add(this.Exitbutton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.petAgeTextBox);
            this.Controls.Add(this.petTypeTextBox);
            this.Controls.Add(this.petNameTextBox);
            this.Controls.Add(this.retrieveInfoButton);
            this.Controls.Add(this.petInformationLabel);
            this.Controls.Add(this.petAgeLabel);
            this.Controls.Add(this.petTypeLabel);
            this.Controls.Add(this.petNameLabel);
            this.Name = "Form1";
            this.Text = "Pet Class";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label petNameLabel;
        private System.Windows.Forms.Label petTypeLabel;
        private System.Windows.Forms.Label petAgeLabel;
        private System.Windows.Forms.Label petInformationLabel;
        private System.Windows.Forms.Button retrieveInfoButton;
        private System.Windows.Forms.TextBox petNameTextBox;
        private System.Windows.Forms.TextBox petTypeTextBox;
        private System.Windows.Forms.TextBox petAgeTextBox;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button Exitbutton;
    }
}