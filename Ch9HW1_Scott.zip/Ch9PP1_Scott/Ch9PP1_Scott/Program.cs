﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms; // Add this to make it work.

namespace Ch9PP1_Scott
{
    class Program
    {
        static void Main()
        {
            // This helps run the program for implementation of classes
            Application.Run(new Form1());
        }
    }
}
