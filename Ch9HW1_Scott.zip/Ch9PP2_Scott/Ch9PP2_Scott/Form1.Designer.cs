﻿namespace Ch9PP2_Scott
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AccelerateButton = new System.Windows.Forms.Button();
            this.breakButton = new System.Windows.Forms.Button();
            this.speedLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.yearLabel = new System.Windows.Forms.Label();
            this.MakeLabel = new System.Windows.Forms.Label();
            this.YeartextBox = new System.Windows.Forms.TextBox();
            this.makeTextBox = new System.Windows.Forms.TextBox();
            this.vehicleTypeGroupBox = new System.Windows.Forms.GroupBox();
            this.displayButton = new System.Windows.Forms.Button();
            this.vehicleLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.vehicleTypeGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // AccelerateButton
            // 
            this.AccelerateButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.AccelerateButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AccelerateButton.Location = new System.Drawing.Point(356, 142);
            this.AccelerateButton.Name = "AccelerateButton";
            this.AccelerateButton.Size = new System.Drawing.Size(75, 23);
            this.AccelerateButton.TabIndex = 0;
            this.AccelerateButton.TabStop = false;
            this.AccelerateButton.Text = "Accelerate";
            this.AccelerateButton.UseVisualStyleBackColor = true;
            this.AccelerateButton.Click += new System.EventHandler(this.AccelerateButton_Click);
            // 
            // breakButton
            // 
            this.breakButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.breakButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.breakButton.Location = new System.Drawing.Point(482, 142);
            this.breakButton.Name = "breakButton";
            this.breakButton.Size = new System.Drawing.Size(75, 23);
            this.breakButton.TabIndex = 1;
            this.breakButton.TabStop = false;
            this.breakButton.Text = "Break";
            this.breakButton.UseVisualStyleBackColor = true;
            this.breakButton.Click += new System.EventHandler(this.breakButton_Click);
            // 
            // speedLabel
            // 
            this.speedLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.speedLabel.Location = new System.Drawing.Point(396, 102);
            this.speedLabel.Name = "speedLabel";
            this.speedLabel.Size = new System.Drawing.Size(133, 23);
            this.speedLabel.TabIndex = 2;
            this.speedLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(328, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(288, 23);
            this.label1.TabIndex = 4;
            this.label1.Text = "Acceleration = 5 mph | Break = - 5 mph.";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitButton
            // 
            this.exitButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.exitButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(425, 181);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 5;
            this.exitButton.TabStop = false;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // yearLabel
            // 
            this.yearLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.yearLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yearLabel.Location = new System.Drawing.Point(17, 35);
            this.yearLabel.Name = "yearLabel";
            this.yearLabel.Size = new System.Drawing.Size(59, 23);
            this.yearLabel.TabIndex = 6;
            this.yearLabel.Text = "Year:";
            this.yearLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MakeLabel
            // 
            this.MakeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MakeLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MakeLabel.Location = new System.Drawing.Point(17, 79);
            this.MakeLabel.Name = "MakeLabel";
            this.MakeLabel.Size = new System.Drawing.Size(59, 23);
            this.MakeLabel.TabIndex = 7;
            this.MakeLabel.Text = "Make:";
            this.MakeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // YeartextBox
            // 
            this.YeartextBox.Location = new System.Drawing.Point(82, 38);
            this.YeartextBox.Name = "YeartextBox";
            this.YeartextBox.Size = new System.Drawing.Size(100, 20);
            this.YeartextBox.TabIndex = 1;
            // 
            // makeTextBox
            // 
            this.makeTextBox.Location = new System.Drawing.Point(82, 82);
            this.makeTextBox.Name = "makeTextBox";
            this.makeTextBox.Size = new System.Drawing.Size(100, 20);
            this.makeTextBox.TabIndex = 2;
            // 
            // vehicleTypeGroupBox
            // 
            this.vehicleTypeGroupBox.Controls.Add(this.clearButton);
            this.vehicleTypeGroupBox.Controls.Add(this.displayButton);
            this.vehicleTypeGroupBox.Controls.Add(this.YeartextBox);
            this.vehicleTypeGroupBox.Controls.Add(this.makeTextBox);
            this.vehicleTypeGroupBox.Controls.Add(this.yearLabel);
            this.vehicleTypeGroupBox.Controls.Add(this.MakeLabel);
            this.vehicleTypeGroupBox.Location = new System.Drawing.Point(38, 23);
            this.vehicleTypeGroupBox.Name = "vehicleTypeGroupBox";
            this.vehicleTypeGroupBox.Size = new System.Drawing.Size(200, 154);
            this.vehicleTypeGroupBox.TabIndex = 10;
            this.vehicleTypeGroupBox.TabStop = false;
            this.vehicleTypeGroupBox.Text = "Vehicle Type and Year";
            // 
            // displayButton
            // 
            this.displayButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.displayButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayButton.Location = new System.Drawing.Point(17, 119);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(75, 23);
            this.displayButton.TabIndex = 3;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // vehicleLabel
            // 
            this.vehicleLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.vehicleLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vehicleLabel.Location = new System.Drawing.Point(272, 23);
            this.vehicleLabel.Name = "vehicleLabel";
            this.vehicleLabel.Size = new System.Drawing.Size(422, 23);
            this.vehicleLabel.TabIndex = 11;
            this.vehicleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // clearButton
            // 
            this.clearButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.clearButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.Location = new System.Drawing.Point(107, 119);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 4;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(706, 217);
            this.Controls.Add(this.vehicleLabel);
            this.Controls.Add(this.vehicleTypeGroupBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.speedLabel);
            this.Controls.Add(this.breakButton);
            this.Controls.Add(this.AccelerateButton);
            this.Name = "Form1";
            this.Text = "Car Acceleration";
            this.vehicleTypeGroupBox.ResumeLayout(false);
            this.vehicleTypeGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button AccelerateButton;
        private System.Windows.Forms.Button breakButton;
        private System.Windows.Forms.Label speedLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label yearLabel;
        private System.Windows.Forms.Label MakeLabel;
        private System.Windows.Forms.TextBox YeartextBox;
        private System.Windows.Forms.TextBox makeTextBox;
        private System.Windows.Forms.GroupBox vehicleTypeGroupBox;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Label vehicleLabel;
        private System.Windows.Forms.Button clearButton;
    }
}