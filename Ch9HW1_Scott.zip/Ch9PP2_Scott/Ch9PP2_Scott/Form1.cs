﻿/**
* 05/11/2018
* CSC 153
* Cameron Scott
* This program test the acceleration of the vehicle of their choice
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ch9PP2_Scott;

namespace Ch9PP2_Scott
{
    public partial class Form1 : Form
    {
        // "Car" the object being use to use methods
        // and variables from a class called "Car."
        // Values within the parentheses are two variables used
        // from the Constructor.
        Car _car = new Car(0, "");
  
        public Form1()
        {
            InitializeComponent();
        }

        private void AccelerateButton_Click(object sender, EventArgs e)
        {
            // Accerlerate and Break methods comes from a class under "car."
            _car.Accelerate();
            speedLabel.Text = _car.speed.ToString();
        }

        private void breakButton_Click(object sender, EventArgs e)
        {
            _car.Brake();
            speedLabel.Text = _car.speed.ToString();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // This closes the program
            this.Close();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
           
            try
            {
               _car.year = int.Parse(YeartextBox.Text);
               _car.make = makeTextBox.Text;
                vehicleLabel.Text = "Let's test out the acceleration of the " + "" + _car.year + " " + _car.make + ".";
            }
            catch
            {
                MessageBox.Show("All fields must be filled in.");
            }

        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            YeartextBox.Text = "";
            makeTextBox.Text = "";
            vehicleLabel.Text = "";
            speedLabel.Text = "";
            YeartextBox.Focus();
        }
    }
}
