﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9PP2_Scott
{
    public class Car
    {
        // Fields
        private int _year;          // Year model for car
        private string _make;       // The make of the car
        private int _speed;         // The current speed of the car

        // Constructor
        public Car(int year, string make)
        {
            _year = year;
            _make = make;
            _speed = 0;
        }


        // Year property
        public int year
        {
            get { return _year; }
            set { _year = value; }
        }

        // Make property
        public string make
        {
            get { return _make; }
            set { _make = value; }
        }

        // Speed property
        public int speed
        {
            get { return _speed; }
            set { _speed = value; }
        }
        // Methods
        public void Accelerate()
        {
            _speed += 5;
            if (_speed >= 125)
            {
                MessageBox.Show(_year + " " + _make + " has reached max acceleration");
                _speed = 120;
            }
        }

        public void Brake()
        {
            _speed -= 5;

            if (_speed <= -5)
            {
                MessageBox.Show(_year + " " + _make + " is at a complete stop.");
                _speed = 0;
            }
        }
       
    }
}
