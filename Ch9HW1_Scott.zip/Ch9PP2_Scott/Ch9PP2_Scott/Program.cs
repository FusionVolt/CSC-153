﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9PP2_Scott
{
    class Program
    {
        static void Main()
        {
            Application.Run(new Form1());
        }
    }
}
