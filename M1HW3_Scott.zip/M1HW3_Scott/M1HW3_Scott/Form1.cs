﻿/**
* 01/29/2017
* CSC 153
* Group 6
* This program shows the visibility of heads or tails
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW3_Scott
{
    public partial class coinBox : Form
    {
        public coinBox()
        {
            InitializeComponent();
        }

        private void HeadsButton_Click(object sender, EventArgs e)
        {
            //This button will only reveal heads.
            headsBox.Visible = true;
            tailsBox.Visible = false;
        }

        private void tailsButton_Click(object sender, EventArgs e)
        {
            //This button will only reveal tails
            tailsBox.Visible = true;
            headsBox.Visible = false;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //This button will close the program
            this.Close();
        }
    }
}
