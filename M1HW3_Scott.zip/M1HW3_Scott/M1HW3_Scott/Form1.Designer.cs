﻿namespace M1HW3_Scott
{
    partial class coinBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tailsBox = new System.Windows.Forms.PictureBox();
            this.headsBox = new System.Windows.Forms.PictureBox();
            this.HeadsButton = new System.Windows.Forms.Button();
            this.tailsButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tailsBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.headsBox)).BeginInit();
            this.SuspendLayout();
            // 
            // tailsBox
            // 
            this.tailsBox.Image = global::M1HW3_Scott.Properties.Resources.us_half_dollar_back;
            this.tailsBox.Location = new System.Drawing.Point(317, 55);
            this.tailsBox.Name = "tailsBox";
            this.tailsBox.Size = new System.Drawing.Size(200, 200);
            this.tailsBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.tailsBox.TabIndex = 1;
            this.tailsBox.TabStop = false;
            this.tailsBox.Visible = false;
            // 
            // headsBox
            // 
            this.headsBox.Image = global::M1HW3_Scott.Properties.Resources.index;
            this.headsBox.Location = new System.Drawing.Point(12, 55);
            this.headsBox.Name = "headsBox";
            this.headsBox.Size = new System.Drawing.Size(200, 200);
            this.headsBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.headsBox.TabIndex = 0;
            this.headsBox.TabStop = false;
            this.headsBox.Visible = false;
            // 
            // HeadsButton
            // 
            this.HeadsButton.Location = new System.Drawing.Point(93, 297);
            this.HeadsButton.Name = "HeadsButton";
            this.HeadsButton.Size = new System.Drawing.Size(75, 38);
            this.HeadsButton.TabIndex = 2;
            this.HeadsButton.Text = "Show Heads";
            this.HeadsButton.UseVisualStyleBackColor = true;
            this.HeadsButton.Click += new System.EventHandler(this.HeadsButton_Click);
            // 
            // tailsButton
            // 
            this.tailsButton.Location = new System.Drawing.Point(205, 297);
            this.tailsButton.Name = "tailsButton";
            this.tailsButton.Size = new System.Drawing.Size(75, 38);
            this.tailsButton.TabIndex = 3;
            this.tailsButton.Text = "Show Tails";
            this.tailsButton.UseVisualStyleBackColor = true;
            this.tailsButton.Click += new System.EventHandler(this.tailsButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(317, 297);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 38);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // coinBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(526, 364);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.tailsButton);
            this.Controls.Add(this.HeadsButton);
            this.Controls.Add(this.tailsBox);
            this.Controls.Add(this.headsBox);
            this.Name = "coinBox";
            this.Text = "Heads or Tails";
            ((System.ComponentModel.ISupportInitialize)(this.tailsBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.headsBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox headsBox;
        private System.Windows.Forms.PictureBox tailsBox;
        private System.Windows.Forms.Button HeadsButton;
        private System.Windows.Forms.Button tailsButton;
        private System.Windows.Forms.Button exitButton;
    }
}

