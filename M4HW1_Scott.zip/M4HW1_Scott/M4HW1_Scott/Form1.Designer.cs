﻿namespace M4HW1_Scott
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exPopulationListBox = new System.Windows.Forms.ListBox();
            this.populationLabel = new System.Windows.Forms.Label();
            this.population1Label = new System.Windows.Forms.Label();
            this.population2Label = new System.Windows.Forms.Label();
            this.orgGrowthLabel = new System.Windows.Forms.Label();
            this.orgGrowthTextBox = new System.Windows.Forms.TextBox();
            this.orgAverageLabel = new System.Windows.Forms.Label();
            this.orgDailyLabel = new System.Windows.Forms.Label();
            this.ResultsButton = new System.Windows.Forms.Button();
            this.orgAverageTextBox = new System.Windows.Forms.TextBox();
            this.orgDailyTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.populationListBox = new System.Windows.Forms.ListBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // exPopulationListBox
            // 
            this.exPopulationListBox.FormattingEnabled = true;
            this.exPopulationListBox.Items.AddRange(new object[] {
            "  1\t\t\t2",
            "  2\t\t\t2.6",
            "  3\t\t\t3.38",
            "  4\t\t\t4.394",
            "  5\t\t\t5.7122",
            "  6\t\t\t7.42586",
            "  7\t\t\t9.653619",
            "  8\t\t\t12.5497",
            "  9\t\t\t16.31462",
            "  10\t\t\t21.209"});
            this.exPopulationListBox.Location = new System.Drawing.Point(143, 141);
            this.exPopulationListBox.Name = "exPopulationListBox";
            this.exPopulationListBox.Size = new System.Drawing.Size(271, 134);
            this.exPopulationListBox.TabIndex = 0;
            this.exPopulationListBox.TabStop = false;
            // 
            // populationLabel
            // 
            this.populationLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.populationLabel.Location = new System.Drawing.Point(139, 110);
            this.populationLabel.Name = "populationLabel";
            this.populationLabel.Size = new System.Drawing.Size(275, 28);
            this.populationLabel.TabIndex = 1;
            this.populationLabel.Text = "Day               Approximate Population";
            this.populationLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // population1Label
            // 
            this.population1Label.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.population1Label.Location = new System.Drawing.Point(84, 50);
            this.population1Label.Name = "population1Label";
            this.population1Label.Size = new System.Drawing.Size(392, 17);
            this.population1Label.TabIndex = 2;
            this.population1Label.Text = "Good day users. Today, we are going to run a organism population test.";
            this.population1Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // population2Label
            // 
            this.population2Label.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.population2Label.Location = new System.Drawing.Point(12, 78);
            this.population2Label.Name = "population2Label";
            this.population2Label.Size = new System.Drawing.Size(551, 17);
            this.population2Label.TabIndex = 3;
            this.population2Label.Text = "The sample below is 2 for starting growth point, 30% daily growth rate and 10 day" +
    "s.";
            this.population2Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // orgGrowthLabel
            // 
            this.orgGrowthLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orgGrowthLabel.Location = new System.Drawing.Point(56, 304);
            this.orgGrowthLabel.Name = "orgGrowthLabel";
            this.orgGrowthLabel.Size = new System.Drawing.Size(247, 17);
            this.orgGrowthLabel.TabIndex = 4;
            this.orgGrowthLabel.Text = "Select a starting point for organism growth:";
            this.orgGrowthLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // orgGrowthTextBox
            // 
            this.orgGrowthTextBox.Location = new System.Drawing.Point(309, 301);
            this.orgGrowthTextBox.Name = "orgGrowthTextBox";
            this.orgGrowthTextBox.Size = new System.Drawing.Size(100, 20);
            this.orgGrowthTextBox.TabIndex = 1;
            // 
            // orgAverageLabel
            // 
            this.orgAverageLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orgAverageLabel.Location = new System.Drawing.Point(35, 332);
            this.orgAverageLabel.Name = "orgAverageLabel";
            this.orgAverageLabel.Size = new System.Drawing.Size(268, 17);
            this.orgAverageLabel.TabIndex = 6;
            this.orgAverageLabel.Text = "Select an average (%)  increase of growth daily:";
            this.orgAverageLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // orgDailyLabel
            // 
            this.orgDailyLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orgDailyLabel.Location = new System.Drawing.Point(15, 361);
            this.orgDailyLabel.Name = "orgDailyLabel";
            this.orgDailyLabel.Size = new System.Drawing.Size(288, 17);
            this.orgDailyLabel.TabIndex = 7;
            this.orgDailyLabel.Text = "Select the number of day for organisms to multiply:";
            this.orgDailyLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ResultsButton
            // 
            this.ResultsButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResultsButton.Location = new System.Drawing.Point(143, 580);
            this.ResultsButton.Name = "ResultsButton";
            this.ResultsButton.Size = new System.Drawing.Size(75, 23);
            this.ResultsButton.TabIndex = 4;
            this.ResultsButton.Text = "Results";
            this.ResultsButton.UseVisualStyleBackColor = true;
            this.ResultsButton.Click += new System.EventHandler(this.ResultsButton_Click);
            // 
            // orgAverageTextBox
            // 
            this.orgAverageTextBox.Location = new System.Drawing.Point(309, 332);
            this.orgAverageTextBox.Name = "orgAverageTextBox";
            this.orgAverageTextBox.Size = new System.Drawing.Size(100, 20);
            this.orgAverageTextBox.TabIndex = 2;
            // 
            // orgDailyTextBox
            // 
            this.orgDailyTextBox.Location = new System.Drawing.Point(309, 361);
            this.orgDailyTextBox.Name = "orgDailyTextBox";
            this.orgDailyTextBox.Size = new System.Drawing.Size(100, 20);
            this.orgDailyTextBox.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(139, 392);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(275, 28);
            this.label1.TabIndex = 12;
            this.label1.Text = "Day               Approximate Population";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // populationListBox
            // 
            this.populationListBox.FormattingEnabled = true;
            this.populationListBox.Location = new System.Drawing.Point(143, 423);
            this.populationListBox.Name = "populationListBox";
            this.populationListBox.Size = new System.Drawing.Size(271, 134);
            this.populationListBox.TabIndex = 11;
            this.populationListBox.TabStop = false;
            // 
            // clearButton
            // 
            this.clearButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.Location = new System.Drawing.Point(241, 580);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 13;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(339, 580);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 14;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(575, 653);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.populationListBox);
            this.Controls.Add(this.orgDailyTextBox);
            this.Controls.Add(this.orgAverageTextBox);
            this.Controls.Add(this.ResultsButton);
            this.Controls.Add(this.orgDailyLabel);
            this.Controls.Add(this.orgAverageLabel);
            this.Controls.Add(this.orgGrowthTextBox);
            this.Controls.Add(this.orgGrowthLabel);
            this.Controls.Add(this.population2Label);
            this.Controls.Add(this.population1Label);
            this.Controls.Add(this.populationLabel);
            this.Controls.Add(this.exPopulationListBox);
            this.Name = "Form1";
            this.Text = "Population";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox exPopulationListBox;
        private System.Windows.Forms.Label populationLabel;
        private System.Windows.Forms.Label population1Label;
        private System.Windows.Forms.Label population2Label;
        private System.Windows.Forms.Label orgGrowthLabel;
        private System.Windows.Forms.TextBox orgGrowthTextBox;
        private System.Windows.Forms.Label orgAverageLabel;
        private System.Windows.Forms.Label orgDailyLabel;
        private System.Windows.Forms.Button ResultsButton;
        private System.Windows.Forms.TextBox orgAverageTextBox;
        private System.Windows.Forms.TextBox orgDailyTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox populationListBox;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

