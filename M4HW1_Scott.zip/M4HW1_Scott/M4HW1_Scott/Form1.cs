﻿/**
* 3/24/2018
* CSC 153
* Cameron Scott
* This program calculate the total population of organisums
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M4HW1_Scott
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ResultsButton_Click(object sender, EventArgs e)
        {
            // Variables
            double organism;            // Starting growth
            int stopGrowth;             // Number of days 
            double groPercent;          // Day by day growth rate
            double groPopulation;       // Placeholder for organism
            
            // Check for errors
            {
                if (double.TryParse(orgAverageTextBox.Text, out groPercent))
                {
                    // Calculate the growth rate
                    groPercent = groPercent / 100;
                    if (int.TryParse(orgDailyTextBox.Text, out stopGrowth))
                    {
                        if (double.TryParse(orgGrowthTextBox.Text, out organism))

                        {
                           
                            groPopulation = organism;

                            // Adds the starting growth input before the calculations.
                            // Tabs to match the days and organism growth in proper spots.
                            populationListBox.Items.Add("1" + "\t\t\t" + organism);

                            for (int count = 2; count <= stopGrowth; count++)
                            {
                                // Calculate the total population of organsiums
                                groPopulation = groPopulation * (1 + groPercent);
                                populationListBox.Items.Add(count + " \t\t\t" + groPopulation);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Invalid input for number");
                            orgGrowthTextBox.Text = "";
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid input for number");
                        orgDailyTextBox.Text = "";
                    }
                }
                else
                {
                    MessageBox.Show("Invalid input for number");
                    orgAverageTextBox.Text = "";
                }
           }
          
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // This clears everything while resests the the tab order.
            orgGrowthTextBox.Focus();
            orgGrowthTextBox.Text = "";
            orgAverageTextBox.Text = "";
            orgDailyTextBox.Text = "";
            populationListBox.Items.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // This closes the program.
            this.Close();
        }

    }
}
