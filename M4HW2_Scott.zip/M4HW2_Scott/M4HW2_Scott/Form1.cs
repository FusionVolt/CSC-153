﻿/**
* 3/24/2018
* CSC 153
* Cameron Scott
* This program randomly rolls the dice per click.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M4HW2_Scott
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tossButton_Click(object sender, EventArgs e)
        {
            int rollDie;        // 6 sided die to the left
            int rollAltDie;     // 6 sided die to the right

            // This creates a random object for dice
            Random rand = new Random();

            // This class randomize the left die between 1 and 6.
            // " + 1"  adds the "next" method to start at 1 instead of zero.
            rollDie = rand.Next(6) + 1;

            if (rollDie == 1)
            {
                dicePictureBox.Image = diceImageList.Images[0];
            }

            else if (rollDie == 2)
            {
                dicePictureBox.Image = diceImageList.Images[1];
            }

            else if (rollDie == 3)
            {
                dicePictureBox.Image = diceImageList.Images[2];
            }

            else if (rollDie == 4)
            {
                dicePictureBox.Image = diceImageList.Images[3];
            }

            else if (rollDie == 5)
            {
                dicePictureBox.Image = diceImageList.Images[4];
            }

            else
            {
                dicePictureBox.Image = diceImageList.Images[5];
            }

            // This class randomize the right die between 1 and 6.
            rollAltDie = rand.Next(6) + 1;

            if (rollAltDie == 1)
            {
                altDicePictureBox.Image = altDiceImageList.Images[0];
            }

            else if (rollAltDie == 2)
            {
                altDicePictureBox.Image = altDiceImageList.Images[1];
            }

            else if (rollAltDie == 3)
            {
                altDicePictureBox.Image = altDiceImageList.Images[2];
            }
            else if (rollAltDie == 4)
            {
                altDicePictureBox.Image = altDiceImageList.Images[3];
            }

            else if (rollAltDie == 5)
            {
                altDicePictureBox.Image = altDiceImageList.Images[4];
            }

            else
            {
                altDicePictureBox.Image = altDiceImageList.Images[5];
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //This closes the program.
            this.Close();
        }

    }
}
