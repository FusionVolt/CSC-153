﻿namespace M4HW2_Scott
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tossButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.diceLabel = new System.Windows.Forms.Label();
            this.altDiceLabel = new System.Windows.Forms.Label();
            this.gagDiceLabel = new System.Windows.Forms.Label();
            this.diceImageList = new System.Windows.Forms.ImageList(this.components);
            this.altDiceImageList = new System.Windows.Forms.ImageList(this.components);
            this.altDicePictureBox = new System.Windows.Forms.PictureBox();
            this.dicePictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.altDicePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dicePictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // tossButton
            // 
            this.tossButton.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tossButton.Location = new System.Drawing.Point(82, 218);
            this.tossButton.Name = "tossButton";
            this.tossButton.Size = new System.Drawing.Size(75, 23);
            this.tossButton.TabIndex = 6;
            this.tossButton.Text = "Toss";
            this.tossButton.UseVisualStyleBackColor = true;
            this.tossButton.Click += new System.EventHandler(this.tossButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(200, 218);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // diceLabel
            // 
            this.diceLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diceLabel.Location = new System.Drawing.Point(12, 29);
            this.diceLabel.Name = "diceLabel";
            this.diceLabel.Size = new System.Drawing.Size(313, 23);
            this.diceLabel.TabIndex = 14;
            this.diceLabel.Text = "Welcome to the Dice Simulator";
            this.diceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // altDiceLabel
            // 
            this.altDiceLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.altDiceLabel.Location = new System.Drawing.Point(12, 68);
            this.altDiceLabel.Name = "altDiceLabel";
            this.altDiceLabel.Size = new System.Drawing.Size(313, 23);
            this.altDiceLabel.TabIndex = 15;
            this.altDiceLabel.Text = "Dare to try you luck? Roll away.";
            this.altDiceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gagDiceLabel
            // 
            this.gagDiceLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gagDiceLabel.Location = new System.Drawing.Point(12, 255);
            this.gagDiceLabel.Name = "gagDiceLabel";
            this.gagDiceLabel.Size = new System.Drawing.Size(328, 23);
            this.gagDiceLabel.TabIndex = 16;
            this.gagDiceLabel.Text = "I can assure you 100% this is not rigged to my favor.";
            this.gagDiceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // diceImageList
            // 
            this.diceImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("diceImageList.ImageStream")));
            this.diceImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.diceImageList.Images.SetKeyName(0, "Die1.bmp");
            this.diceImageList.Images.SetKeyName(1, "Die2.bmp");
            this.diceImageList.Images.SetKeyName(2, "Die3.bmp");
            this.diceImageList.Images.SetKeyName(3, "Die4.bmp");
            this.diceImageList.Images.SetKeyName(4, "Die5.bmp");
            this.diceImageList.Images.SetKeyName(5, "Die6.bmp");
            // 
            // altDiceImageList
            // 
            this.altDiceImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("altDiceImageList.ImageStream")));
            this.altDiceImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.altDiceImageList.Images.SetKeyName(0, "Die1.bmp");
            this.altDiceImageList.Images.SetKeyName(1, "Die2.bmp");
            this.altDiceImageList.Images.SetKeyName(2, "Die3.bmp");
            this.altDiceImageList.Images.SetKeyName(3, "Die4.bmp");
            this.altDiceImageList.Images.SetKeyName(4, "Die5.bmp");
            this.altDiceImageList.Images.SetKeyName(5, "Die6.bmp");
            // 
            // altDicePictureBox
            // 
            this.altDicePictureBox.Image = global::M4HW2_Scott.Properties.Resources.Die6;
            this.altDicePictureBox.Location = new System.Drawing.Point(185, 107);
            this.altDicePictureBox.Name = "altDicePictureBox";
            this.altDicePictureBox.Size = new System.Drawing.Size(117, 81);
            this.altDicePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.altDicePictureBox.TabIndex = 13;
            this.altDicePictureBox.TabStop = false;
            // 
            // dicePictureBox
            // 
            this.dicePictureBox.Image = global::M4HW2_Scott.Properties.Resources.Die6;
            this.dicePictureBox.Location = new System.Drawing.Point(62, 107);
            this.dicePictureBox.Name = "dicePictureBox";
            this.dicePictureBox.Size = new System.Drawing.Size(117, 81);
            this.dicePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.dicePictureBox.TabIndex = 5;
            this.dicePictureBox.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(352, 312);
            this.Controls.Add(this.gagDiceLabel);
            this.Controls.Add(this.altDiceLabel);
            this.Controls.Add(this.diceLabel);
            this.Controls.Add(this.altDicePictureBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.tossButton);
            this.Controls.Add(this.dicePictureBox);
            this.Name = "Form1";
            this.Text = "Dice Simulator";
            ((System.ComponentModel.ISupportInitialize)(this.altDicePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dicePictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox dicePictureBox;
        private System.Windows.Forms.Button tossButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.PictureBox altDicePictureBox;
        private System.Windows.Forms.Label diceLabel;
        private System.Windows.Forms.Label altDiceLabel;
        private System.Windows.Forms.Label gagDiceLabel;
        private System.Windows.Forms.ImageList diceImageList;
        private System.Windows.Forms.ImageList altDiceImageList;
    }
}

