﻿namespace M3HW2_Scott
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.quantityTextBox = new System.Windows.Forms.TextBox();
            this.quantLabel = new System.Windows.Forms.Label();
            this.quant1Label = new System.Windows.Forms.Label();
            this.discountLabel = new System.Windows.Forms.Label();
            this.quant2Label = new System.Windows.Forms.Label();
            this.grandLabel = new System.Windows.Forms.Label();
            this.calcButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // quantityTextBox
            // 
            this.quantityTextBox.Location = new System.Drawing.Point(105, 63);
            this.quantityTextBox.Name = "quantityTextBox";
            this.quantityTextBox.Size = new System.Drawing.Size(133, 20);
            this.quantityTextBox.TabIndex = 0;
            this.quantityTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // quantLabel
            // 
            this.quantLabel.Location = new System.Drawing.Point(43, 19);
            this.quantLabel.Name = "quantLabel";
            this.quantLabel.Size = new System.Drawing.Size(266, 23);
            this.quantLabel.TabIndex = 1;
            this.quantLabel.Text = "Select the number of packages you like to purchase:";
            this.quantLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // quant1Label
            // 
            this.quant1Label.Location = new System.Drawing.Point(43, 100);
            this.quant1Label.Name = "quant1Label";
            this.quant1Label.Size = new System.Drawing.Size(266, 23);
            this.quant1Label.TabIndex = 2;
            this.quant1Label.Text = "The quantity you have purchased will save you:";
            this.quant1Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // discountLabel
            // 
            this.discountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.discountLabel.Location = new System.Drawing.Point(46, 135);
            this.discountLabel.Name = "discountLabel";
            this.discountLabel.Size = new System.Drawing.Size(266, 23);
            this.discountLabel.TabIndex = 3;
            this.discountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // quant2Label
            // 
            this.quant2Label.Location = new System.Drawing.Point(46, 169);
            this.quant2Label.Name = "quant2Label";
            this.quant2Label.Size = new System.Drawing.Size(266, 23);
            this.quant2Label.TabIndex = 4;
            this.quant2Label.Text = "Your grand total with or without a discount will be:";
            this.quant2Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grandLabel
            // 
            this.grandLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.grandLabel.Location = new System.Drawing.Point(43, 206);
            this.grandLabel.Name = "grandLabel";
            this.grandLabel.Size = new System.Drawing.Size(266, 23);
            this.grandLabel.TabIndex = 5;
            this.grandLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(43, 261);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(75, 40);
            this.calcButton.TabIndex = 6;
            this.calcButton.Text = "Calculate Purchase";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(139, 261);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 40);
            this.clearButton.TabIndex = 7;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(237, 261);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 40);
            this.exitButton.TabIndex = 8;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(355, 327);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.grandLabel);
            this.Controls.Add(this.quant2Label);
            this.Controls.Add(this.discountLabel);
            this.Controls.Add(this.quant1Label);
            this.Controls.Add(this.quantLabel);
            this.Controls.Add(this.quantityTextBox);
            this.Name = "Form1";
            this.Text = "Software Sales";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox quantityTextBox;
        private System.Windows.Forms.Label quantLabel;
        private System.Windows.Forms.Label quant1Label;
        private System.Windows.Forms.Label discountLabel;
        private System.Windows.Forms.Label quant2Label;
        private System.Windows.Forms.Label grandLabel;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

