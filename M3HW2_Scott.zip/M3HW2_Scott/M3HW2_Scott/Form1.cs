﻿/**
* 02/28/2018
* CSC 153
* Cameron Scott
* This program calculates the discount ranges for packages bought.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW2_Scott
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private string letter;
        private void calcButton_Click(object sender, EventArgs e)
        {
            int package;        // To hold the number of packages the user inputs in
            int amount;         // To hold price for each packages
            double discount;    // To hold the discount for fixed number of purchased packages
            double grand;       // To show the grand total of the purchase
            double subTotal;    // To show the amount of money would be save
            letter = "$";       // To add the dollar sign with the number

            if (int.TryParse(quantityTextBox.Text, out package))
            {
                // This calculates the sub & grand total depending on how many packages the user bought.
                // "n2" formats the double by 2 decmal places.
                if (package >= 10 && package <= 19)
                {
                    amount = 99 * package;
                    discount = .2;
                    subTotal = amount * discount;
                    grand = amount - subTotal;
                    discountLabel.Text = letter + subTotal.ToString("n2");
                    grandLabel.Text = letter + grand.ToString("n2");

                }
                else if (package >= 20 && package <= 49)
                {
                    amount = 99 * package;
                    discount = .3;
                    subTotal = amount * discount;
                    grand = amount - subTotal;
                    discountLabel.Text = letter + subTotal.ToString("n2");
                    grandLabel.Text = letter + grand.ToString("n2");
                }
                else if (package >= 50 && package <= 99)
                {
                    amount = 99 * package;
                    discount = .4;
                    subTotal = amount * discount;
                    grand = amount - subTotal;
                    discountLabel.Text = letter + subTotal.ToString("n2");
                    grandLabel.Text = letter + grand.ToString("n2");
                }
                else if (package >= 100)
                {
                    amount = 99 * package;
                    discount = .5;
                    subTotal = amount * discount;
                    grand = amount - subTotal;
                    discountLabel.Text = letter + subTotal.ToString("n2");
                    grandLabel.Text = letter + grand.ToString("n2");
                }
                else
                {
                    amount = 99 * package;
                    discount = 0;
                    subTotal = amount * discount;
                    grand = amount - subTotal;
                    discountLabel.Text = letter + subTotal.ToString("n2");
                    grandLabel.Text = letter + grand.ToString("n2");
                }
            }
            else
            {
                // This prevents the user of inputing any but a number.
                MessageBox.Show("Invalid input for number of package");
                quantityTextBox.Text = "";
                quantityTextBox.Focus();
            }


        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // This clears the text.
            quantityTextBox.Text = "";
            discountLabel.Text = "";
            grandLabel.Text = "";
            // This resets the focus to the textbox.
            quantityTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // This closes the program.
            this.Close();
        }
    }
}
