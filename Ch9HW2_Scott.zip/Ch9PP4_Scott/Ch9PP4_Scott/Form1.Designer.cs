﻿namespace Ch9PP4_Scott
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.@__nameLabel = new System.Windows.Forms.Label();
            this.@__idLabel = new System.Windows.Forms.Label();
            this.@__departmentLabel = new System.Windows.Forms.Label();
            this.@__PositionLabel = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.idNumberTextBox = new System.Windows.Forms.TextBox();
            this.departmentTextBox = new System.Windows.Forms.TextBox();
            this.positionTextBox = new System.Windows.Forms.TextBox();
            this.nameListBox = new System.Windows.Forms.ListBox();
            this.idNumberListBox = new System.Windows.Forms.ListBox();
            this.departmentListBox = new System.Windows.Forms.ListBox();
            this.positionListBox = new System.Windows.Forms.ListBox();
            this.insertButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.infoClearButton = new System.Windows.Forms.Button();
            this.nameLabel1 = new System.Windows.Forms.Label();
            this.idNumberLabel1 = new System.Windows.Forms.Label();
            this.DepartmentLabel1 = new System.Windows.Forms.Label();
            this.positionLabel1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // __nameLabel
            // 
            this.@__nameLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.@__nameLabel.Location = new System.Drawing.Point(12, 49);
            this.@__nameLabel.Name = "__nameLabel";
            this.@__nameLabel.Size = new System.Drawing.Size(100, 23);
            this.@__nameLabel.TabIndex = 0;
            this.@__nameLabel.Text = "Name:";
            this.@__nameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // __idLabel
            // 
            this.@__idLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.@__idLabel.Location = new System.Drawing.Point(12, 83);
            this.@__idLabel.Name = "__idLabel";
            this.@__idLabel.Size = new System.Drawing.Size(100, 23);
            this.@__idLabel.TabIndex = 0;
            this.@__idLabel.Text = "ID Number:";
            this.@__idLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // __departmentLabel
            // 
            this.@__departmentLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.@__departmentLabel.Location = new System.Drawing.Point(12, 121);
            this.@__departmentLabel.Name = "__departmentLabel";
            this.@__departmentLabel.Size = new System.Drawing.Size(100, 23);
            this.@__departmentLabel.TabIndex = 0;
            this.@__departmentLabel.Text = "Department:";
            this.@__departmentLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // __PositionLabel
            // 
            this.@__PositionLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.@__PositionLabel.Location = new System.Drawing.Point(12, 156);
            this.@__PositionLabel.Name = "__PositionLabel";
            this.@__PositionLabel.Size = new System.Drawing.Size(100, 23);
            this.@__PositionLabel.TabIndex = 0;
            this.@__PositionLabel.Text = "Position:";
            this.@__PositionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(129, 52);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 1;
            // 
            // idNumberTextBox
            // 
            this.idNumberTextBox.Location = new System.Drawing.Point(129, 86);
            this.idNumberTextBox.Name = "idNumberTextBox";
            this.idNumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.idNumberTextBox.TabIndex = 2;
            // 
            // departmentTextBox
            // 
            this.departmentTextBox.Location = new System.Drawing.Point(129, 121);
            this.departmentTextBox.Name = "departmentTextBox";
            this.departmentTextBox.Size = new System.Drawing.Size(100, 20);
            this.departmentTextBox.TabIndex = 3;
            // 
            // positionTextBox
            // 
            this.positionTextBox.Location = new System.Drawing.Point(129, 156);
            this.positionTextBox.Name = "positionTextBox";
            this.positionTextBox.Size = new System.Drawing.Size(100, 20);
            this.positionTextBox.TabIndex = 4;
            // 
            // nameListBox
            // 
            this.nameListBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameListBox.FormattingEnabled = true;
            this.nameListBox.ItemHeight = 15;
            this.nameListBox.Location = new System.Drawing.Point(256, 49);
            this.nameListBox.Name = "nameListBox";
            this.nameListBox.Size = new System.Drawing.Size(112, 94);
            this.nameListBox.TabIndex = 5;
            this.nameListBox.TabStop = false;
            // 
            // idNumberListBox
            // 
            this.idNumberListBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idNumberListBox.FormattingEnabled = true;
            this.idNumberListBox.ItemHeight = 15;
            this.idNumberListBox.Location = new System.Drawing.Point(374, 49);
            this.idNumberListBox.Name = "idNumberListBox";
            this.idNumberListBox.Size = new System.Drawing.Size(76, 94);
            this.idNumberListBox.TabIndex = 6;
            this.idNumberListBox.TabStop = false;
            // 
            // departmentListBox
            // 
            this.departmentListBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.departmentListBox.FormattingEnabled = true;
            this.departmentListBox.ItemHeight = 15;
            this.departmentListBox.Location = new System.Drawing.Point(456, 49);
            this.departmentListBox.Name = "departmentListBox";
            this.departmentListBox.Size = new System.Drawing.Size(112, 94);
            this.departmentListBox.TabIndex = 7;
            this.departmentListBox.TabStop = false;
            // 
            // positionListBox
            // 
            this.positionListBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.positionListBox.FormattingEnabled = true;
            this.positionListBox.ItemHeight = 15;
            this.positionListBox.Location = new System.Drawing.Point(574, 49);
            this.positionListBox.Name = "positionListBox";
            this.positionListBox.Size = new System.Drawing.Size(112, 94);
            this.positionListBox.TabIndex = 8;
            this.positionListBox.TabStop = false;
            // 
            // insertButton
            // 
            this.insertButton.Location = new System.Drawing.Point(49, 206);
            this.insertButton.Name = "insertButton";
            this.insertButton.Size = new System.Drawing.Size(75, 23);
            this.insertButton.TabIndex = 9;
            this.insertButton.Text = "Insert";
            this.insertButton.UseVisualStyleBackColor = true;
            this.insertButton.Click += new System.EventHandler(this.insertButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(144, 206);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 10;
            this.clearButton.Text = "Clear Field";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(239, 206);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(75, 23);
            this.ExitButton.TabIndex = 11;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // infoClearButton
            // 
            this.infoClearButton.Location = new System.Drawing.Point(429, 157);
            this.infoClearButton.Name = "infoClearButton";
            this.infoClearButton.Size = new System.Drawing.Size(75, 23);
            this.infoClearButton.TabIndex = 12;
            this.infoClearButton.Text = "Clear Info";
            this.infoClearButton.UseVisualStyleBackColor = true;
            this.infoClearButton.Click += new System.EventHandler(this.infoClearButton_Click);
            // 
            // nameLabel1
            // 
            this.nameLabel1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel1.Location = new System.Drawing.Point(252, 23);
            this.nameLabel1.Name = "nameLabel1";
            this.nameLabel1.Size = new System.Drawing.Size(116, 23);
            this.nameLabel1.TabIndex = 13;
            this.nameLabel1.Text = "Name";
            this.nameLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // idNumberLabel1
            // 
            this.idNumberLabel1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idNumberLabel1.Location = new System.Drawing.Point(370, 23);
            this.idNumberLabel1.Name = "idNumberLabel1";
            this.idNumberLabel1.Size = new System.Drawing.Size(80, 23);
            this.idNumberLabel1.TabIndex = 14;
            this.idNumberLabel1.Text = "ID Number";
            this.idNumberLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DepartmentLabel1
            // 
            this.DepartmentLabel1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DepartmentLabel1.Location = new System.Drawing.Point(456, 23);
            this.DepartmentLabel1.Name = "DepartmentLabel1";
            this.DepartmentLabel1.Size = new System.Drawing.Size(112, 23);
            this.DepartmentLabel1.TabIndex = 15;
            this.DepartmentLabel1.Text = "Department";
            this.DepartmentLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // positionLabel1
            // 
            this.positionLabel1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.positionLabel1.Location = new System.Drawing.Point(570, 23);
            this.positionLabel1.Name = "positionLabel1";
            this.positionLabel1.Size = new System.Drawing.Size(116, 23);
            this.positionLabel1.TabIndex = 16;
            this.positionLabel1.Text = "Position";
            this.positionLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(701, 269);
            this.Controls.Add(this.positionLabel1);
            this.Controls.Add(this.DepartmentLabel1);
            this.Controls.Add(this.idNumberLabel1);
            this.Controls.Add(this.nameLabel1);
            this.Controls.Add(this.infoClearButton);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.insertButton);
            this.Controls.Add(this.positionListBox);
            this.Controls.Add(this.departmentListBox);
            this.Controls.Add(this.idNumberListBox);
            this.Controls.Add(this.nameListBox);
            this.Controls.Add(this.positionTextBox);
            this.Controls.Add(this.departmentTextBox);
            this.Controls.Add(this.idNumberTextBox);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.@__PositionLabel);
            this.Controls.Add(this.@__departmentLabel);
            this.Controls.Add(this.@__idLabel);
            this.Controls.Add(this.@__nameLabel);
            this.Name = "Form1";
            this.Text = "Employee";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label __nameLabel;
        private System.Windows.Forms.Label __idLabel;
        private System.Windows.Forms.Label __departmentLabel;
        private System.Windows.Forms.Label __PositionLabel;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox idNumberTextBox;
        private System.Windows.Forms.TextBox departmentTextBox;
        private System.Windows.Forms.TextBox positionTextBox;
        private System.Windows.Forms.ListBox nameListBox;
        private System.Windows.Forms.ListBox idNumberListBox;
        private System.Windows.Forms.ListBox departmentListBox;
        private System.Windows.Forms.ListBox positionListBox;
        private System.Windows.Forms.Button insertButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button infoClearButton;
        private System.Windows.Forms.Label nameLabel1;
        private System.Windows.Forms.Label idNumberLabel1;
        private System.Windows.Forms.Label DepartmentLabel1;
        private System.Windows.Forms.Label positionLabel1;
    }
}

