﻿/**
* 05/11/2018
* CSC 153
* Cameron Scott
* This program displays information of each employee and their fields
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9PP4_Scott
{
    public partial class Form1 : Form
    {
        Employee _Employee = new Employee();
        public Form1()
        {
            InitializeComponent();
        }

        private void insertButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Enter information in form.
                _Employee.name = nameTextBox.Text;
                _Employee.idNumber = int.Parse(idNumberTextBox.Text);
                _Employee.department = departmentTextBox.Text;
                _Employee.position = positionTextBox.Text;

                // Adds the information to the listboxes.
                nameListBox.Items.Add(_Employee.name);
                idNumberListBox.Items.Add(_Employee.idNumber);
                departmentListBox.Items.Add(_Employee.department);
                positionListBox.Items.Add(_Employee.position);

                // Clears the fields
                nameTextBox.Text = "";
                idNumberTextBox.Text = "";
                departmentTextBox.Text = "";
                positionTextBox.Text = "";

                // Refocus back to the name field.
                nameTextBox.Focus();
            }
            catch (Exception)
            {
                MessageBox.Show ("Please enter the following fields");
            }
           
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clears the fields
            nameTextBox.Text = "";
            idNumberTextBox.Text = "";
            departmentTextBox.Text = "";
            positionTextBox.Text = "";

            // Refocus back to the name field.
            nameTextBox.Focus();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            // Exits the program
            this.Close();
        }

        private void infoClearButton_Click(object sender, EventArgs e)
        {
            nameListBox.Items.Clear();
            idNumberListBox.Items.Clear();
            departmentListBox.Items.Clear();
            positionListBox.Items.Clear();
        }
    }
}
