﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch9PP4_Scott
{
    public class Employee
    {
        // Fields
        private string _name;           // Employee's Name
        private int _idNumber;          // Employee's ID Number
        private string _department;     // Name of Department
        private string _position;       // The employee's job title

        // Constructor
        public Employee()
        {
            _name = name;
            _idNumber = idNumber;
            _department = department;
            _position = position;
        }

        // Constructor
        public Employee(string department, string position)
        {
            _name = name;
            _idNumber = idNumber;
            _department = "";
            _position = "";
        }

        // Constructor
        public Employee(string name, int idNumber, string department, string position)
        {
            _name = "";
            _idNumber = 0;
            _department = "";
            _position = "";
        }
        
        // Name property
        public string name
        {
            get { return _name; }
            set { _name = value; }
        }

        // Id Number property
        public int idNumber
        {
            get { return _idNumber; }
            set { _idNumber = value; }
        }

        // Department property
        public string department
        {
            get { return _department; }
            set { _department = value; }
        }

        // Position property
        public string position
        {
            get { return _position; }
            set { _position = value; }
        }
       
    }
    
}
