﻿/**
* 05/09/2018
* CSC 153
* Cameron Scott
* This program displays information of both users and their friends of famliy.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9PP3_Scott
{    
    public partial class Form1 : Form
    {
        // The name of a class highlighted in light blue (object) is like a folder.
        // A folder that contains the variables and methods to gain access to
        Personal_Information _personalInformation = new Personal_Information();
        public Form1()
        {
            InitializeComponent();
        }

        private void getInfoButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Enter personal information
                _personalInformation.name = nameTextBox.Text;
                _personalInformation.address = addressTextBox.Text;
                _personalInformation.age = int.Parse(ageTextBox.Text);
                _personalInformation.phone = phoneTextBox.Text;

                myInfoListBox.Items.Add("Name: \t" + _personalInformation.name);
                myInfoListBox.Items.Add("");
                myInfoListBox.Items.Add("Address: \t" + _personalInformation.address);
                myInfoListBox.Items.Add("");
                myInfoListBox.Items.Add("Age: \t" + _personalInformation.age.ToString());
                myInfoListBox.Items.Add("");
                myInfoListBox.Items.Add("Phone: \t" + _personalInformation.phone);
            }
            catch
            {
                MessageBox.Show("Please fill in the fields.");
            }
           
        }

        private void getInfo1button_Click(object sender, EventArgs e)
        {
            try
            {
                // Enter family or friends' information
                _personalInformation.name = name1TextBox.Text;
                _personalInformation.address = address1TextBox.Text;
                _personalInformation.age = int.Parse(age1TextBox.Text);
                _personalInformation.phone = phone1TextBox.Text;

                famliy_FriendsListBox.Items.Add("Name: \t" + _personalInformation.name);
                famliy_FriendsListBox.Items.Add("");
                famliy_FriendsListBox.Items.Add("Address: \t" + _personalInformation.address);
                famliy_FriendsListBox.Items.Add("");
                famliy_FriendsListBox.Items.Add("Age: \t" + _personalInformation.age.ToString());
                famliy_FriendsListBox.Items.Add("");
                famliy_FriendsListBox.Items.Add("Phone: \t" + _personalInformation.phone);
            }
            catch
            {
                MessageBox.Show("Please enter the following fields");
            }
            
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clears personal information
            nameTextBox.Text = "";
            addressTextBox.Text = "";
            ageTextBox.Text = "";
            phoneTextBox.Text = "";
        }

        private void clear1Button_Click(object sender, EventArgs e)
        {
            // Clears family or friends' information.
            name1TextBox.Text = "";
            address1TextBox.Text = "";
            age1TextBox.Text = "";
            phone1TextBox.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // This closes the program.
            this.Close();
        }
    }
}
