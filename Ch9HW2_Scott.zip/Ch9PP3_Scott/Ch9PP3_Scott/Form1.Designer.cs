﻿namespace Ch9PP3_Scott
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.getInfoButton = new System.Windows.Forms.Button();
            this.phoneTextBox = new System.Windows.Forms.TextBox();
            this.ageTextBox = new System.Windows.Forms.TextBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.PhoneLabel = new System.Windows.Forms.Label();
            this.ageLabel = new System.Windows.Forms.Label();
            this.addressLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.clear1Button = new System.Windows.Forms.Button();
            this.getInfo1button = new System.Windows.Forms.Button();
            this.phone1TextBox = new System.Windows.Forms.TextBox();
            this.age1TextBox = new System.Windows.Forms.TextBox();
            this.address1TextBox = new System.Windows.Forms.TextBox();
            this.name1TextBox = new System.Windows.Forms.TextBox();
            this.phone1Label = new System.Windows.Forms.Label();
            this.age1Label = new System.Windows.Forms.Label();
            this.address1Llabel = new System.Windows.Forms.Label();
            this.name1Label = new System.Windows.Forms.Label();
            this.summaryGroupBox = new System.Windows.Forms.GroupBox();
            this.famliy_FriendsListBox = new System.Windows.Forms.ListBox();
            this.myInfoListBox = new System.Windows.Forms.ListBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.SummaryLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.summaryGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.clearButton);
            this.groupBox1.Controls.Add(this.getInfoButton);
            this.groupBox1.Controls.Add(this.phoneTextBox);
            this.groupBox1.Controls.Add(this.ageTextBox);
            this.groupBox1.Controls.Add(this.addressTextBox);
            this.groupBox1.Controls.Add(this.nameTextBox);
            this.groupBox1.Controls.Add(this.PhoneLabel);
            this.groupBox1.Controls.Add(this.ageLabel);
            this.groupBox1.Controls.Add(this.addressLabel);
            this.groupBox1.Controls.Add(this.nameLabel);
            this.groupBox1.Location = new System.Drawing.Point(23, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(225, 250);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Your information";
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(120, 202);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 5;
            this.clearButton.TabStop = false;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // getInfoButton
            // 
            this.getInfoButton.Location = new System.Drawing.Point(26, 202);
            this.getInfoButton.Name = "getInfoButton";
            this.getInfoButton.Size = new System.Drawing.Size(75, 23);
            this.getInfoButton.TabIndex = 4;
            this.getInfoButton.TabStop = false;
            this.getInfoButton.Text = "Enter";
            this.getInfoButton.UseVisualStyleBackColor = true;
            this.getInfoButton.Click += new System.EventHandler(this.getInfoButton_Click);
            // 
            // phoneTextBox
            // 
            this.phoneTextBox.Location = new System.Drawing.Point(107, 156);
            this.phoneTextBox.Name = "phoneTextBox";
            this.phoneTextBox.Size = new System.Drawing.Size(100, 20);
            this.phoneTextBox.TabIndex = 3;
            // 
            // ageTextBox
            // 
            this.ageTextBox.Location = new System.Drawing.Point(107, 112);
            this.ageTextBox.Name = "ageTextBox";
            this.ageTextBox.Size = new System.Drawing.Size(100, 20);
            this.ageTextBox.TabIndex = 2;
            // 
            // addressTextBox
            // 
            this.addressTextBox.Location = new System.Drawing.Point(107, 70);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(100, 20);
            this.addressTextBox.TabIndex = 1;
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(107, 33);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 0;
            // 
            // PhoneLabel
            // 
            this.PhoneLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneLabel.Location = new System.Drawing.Point(12, 154);
            this.PhoneLabel.Name = "PhoneLabel";
            this.PhoneLabel.Size = new System.Drawing.Size(89, 23);
            this.PhoneLabel.TabIndex = 0;
            this.PhoneLabel.Text = "Phone Number:";
            this.PhoneLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ageLabel
            // 
            this.ageLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ageLabel.Location = new System.Drawing.Point(12, 107);
            this.ageLabel.Name = "ageLabel";
            this.ageLabel.Size = new System.Drawing.Size(89, 23);
            this.ageLabel.TabIndex = 0;
            this.ageLabel.Text = "Age:";
            this.ageLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addressLabel
            // 
            this.addressLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addressLabel.Location = new System.Drawing.Point(12, 68);
            this.addressLabel.Name = "addressLabel";
            this.addressLabel.Size = new System.Drawing.Size(89, 23);
            this.addressLabel.TabIndex = 0;
            this.addressLabel.Text = "Address:";
            this.addressLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // nameLabel
            // 
            this.nameLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel.Location = new System.Drawing.Point(12, 30);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(89, 23);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Name:";
            this.nameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.clear1Button);
            this.groupBox2.Controls.Add(this.getInfo1button);
            this.groupBox2.Controls.Add(this.phone1TextBox);
            this.groupBox2.Controls.Add(this.age1TextBox);
            this.groupBox2.Controls.Add(this.address1TextBox);
            this.groupBox2.Controls.Add(this.name1TextBox);
            this.groupBox2.Controls.Add(this.phone1Label);
            this.groupBox2.Controls.Add(this.age1Label);
            this.groupBox2.Controls.Add(this.address1Llabel);
            this.groupBox2.Controls.Add(this.name1Label);
            this.groupBox2.Location = new System.Drawing.Point(266, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(229, 250);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Family/Friends\' infomation";
            // 
            // clear1Button
            // 
            this.clear1Button.Location = new System.Drawing.Point(114, 200);
            this.clear1Button.Name = "clear1Button";
            this.clear1Button.Size = new System.Drawing.Size(75, 23);
            this.clear1Button.TabIndex = 10;
            this.clear1Button.TabStop = false;
            this.clear1Button.Text = "Clear";
            this.clear1Button.UseVisualStyleBackColor = true;
            this.clear1Button.Click += new System.EventHandler(this.clear1Button_Click);
            // 
            // getInfo1button
            // 
            this.getInfo1button.Location = new System.Drawing.Point(20, 200);
            this.getInfo1button.Name = "getInfo1button";
            this.getInfo1button.Size = new System.Drawing.Size(75, 23);
            this.getInfo1button.TabIndex = 9;
            this.getInfo1button.TabStop = false;
            this.getInfo1button.Text = "Enter";
            this.getInfo1button.UseVisualStyleBackColor = true;
            this.getInfo1button.Click += new System.EventHandler(this.getInfo1button_Click);
            // 
            // phone1TextBox
            // 
            this.phone1TextBox.Location = new System.Drawing.Point(101, 152);
            this.phone1TextBox.Name = "phone1TextBox";
            this.phone1TextBox.Size = new System.Drawing.Size(100, 20);
            this.phone1TextBox.TabIndex = 7;
            // 
            // age1TextBox
            // 
            this.age1TextBox.Location = new System.Drawing.Point(101, 110);
            this.age1TextBox.Name = "age1TextBox";
            this.age1TextBox.Size = new System.Drawing.Size(100, 20);
            this.age1TextBox.TabIndex = 6;
            // 
            // address1TextBox
            // 
            this.address1TextBox.Location = new System.Drawing.Point(101, 71);
            this.address1TextBox.Name = "address1TextBox";
            this.address1TextBox.Size = new System.Drawing.Size(100, 20);
            this.address1TextBox.TabIndex = 5;
            // 
            // name1TextBox
            // 
            this.name1TextBox.Location = new System.Drawing.Point(101, 33);
            this.name1TextBox.Name = "name1TextBox";
            this.name1TextBox.Size = new System.Drawing.Size(100, 20);
            this.name1TextBox.TabIndex = 4;
            // 
            // phone1Label
            // 
            this.phone1Label.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phone1Label.Location = new System.Drawing.Point(6, 154);
            this.phone1Label.Name = "phone1Label";
            this.phone1Label.Size = new System.Drawing.Size(89, 23);
            this.phone1Label.TabIndex = 0;
            this.phone1Label.Text = "Phone Number:";
            this.phone1Label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // age1Label
            // 
            this.age1Label.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.age1Label.Location = new System.Drawing.Point(6, 107);
            this.age1Label.Name = "age1Label";
            this.age1Label.Size = new System.Drawing.Size(89, 23);
            this.age1Label.TabIndex = 0;
            this.age1Label.Text = "Age:";
            this.age1Label.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // address1Llabel
            // 
            this.address1Llabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address1Llabel.Location = new System.Drawing.Point(6, 68);
            this.address1Llabel.Name = "address1Llabel";
            this.address1Llabel.Size = new System.Drawing.Size(89, 23);
            this.address1Llabel.TabIndex = 0;
            this.address1Llabel.Text = "Address:";
            this.address1Llabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // name1Label
            // 
            this.name1Label.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name1Label.Location = new System.Drawing.Point(6, 30);
            this.name1Label.Name = "name1Label";
            this.name1Label.Size = new System.Drawing.Size(89, 23);
            this.name1Label.TabIndex = 0;
            this.name1Label.Text = "Name:";
            this.name1Label.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // summaryGroupBox
            // 
            this.summaryGroupBox.Controls.Add(this.SummaryLabel);
            this.summaryGroupBox.Controls.Add(this.famliy_FriendsListBox);
            this.summaryGroupBox.Controls.Add(this.myInfoListBox);
            this.summaryGroupBox.Location = new System.Drawing.Point(516, 2);
            this.summaryGroupBox.Name = "summaryGroupBox";
            this.summaryGroupBox.Size = new System.Drawing.Size(342, 248);
            this.summaryGroupBox.TabIndex = 1;
            this.summaryGroupBox.TabStop = false;
            this.summaryGroupBox.Text = "Summary";
            // 
            // famliy_FriendsListBox
            // 
            this.famliy_FriendsListBox.FormattingEnabled = true;
            this.famliy_FriendsListBox.Location = new System.Drawing.Point(172, 37);
            this.famliy_FriendsListBox.Name = "famliy_FriendsListBox";
            this.famliy_FriendsListBox.Size = new System.Drawing.Size(147, 186);
            this.famliy_FriendsListBox.TabIndex = 0;
            this.famliy_FriendsListBox.TabStop = false;
            // 
            // myInfoListBox
            // 
            this.myInfoListBox.FormattingEnabled = true;
            this.myInfoListBox.Location = new System.Drawing.Point(6, 37);
            this.myInfoListBox.Name = "myInfoListBox";
            this.myInfoListBox.Size = new System.Drawing.Size(137, 186);
            this.myInfoListBox.TabIndex = 0;
            this.myInfoListBox.TabStop = false;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(223, 258);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 13;
            this.exitButton.TabStop = false;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // SummaryLabel
            // 
            this.SummaryLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryLabel.Location = new System.Drawing.Point(6, 16);
            this.SummaryLabel.Name = "SummaryLabel";
            this.SummaryLabel.Size = new System.Drawing.Size(313, 23);
            this.SummaryLabel.TabIndex = 1;
            this.SummaryLabel.Text = "Your information                        Famliy/Friend\'s information";
            this.SummaryLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(882, 291);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.summaryGroupBox);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Personal Information";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.summaryGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox summaryGroupBox;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button getInfoButton;
        private System.Windows.Forms.TextBox phoneTextBox;
        private System.Windows.Forms.TextBox ageTextBox;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Label PhoneLabel;
        private System.Windows.Forms.Label ageLabel;
        private System.Windows.Forms.Label addressLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Button clear1Button;
        private System.Windows.Forms.Button getInfo1button;
        private System.Windows.Forms.TextBox phone1TextBox;
        private System.Windows.Forms.TextBox age1TextBox;
        private System.Windows.Forms.TextBox address1TextBox;
        private System.Windows.Forms.TextBox name1TextBox;
        private System.Windows.Forms.Label phone1Label;
        private System.Windows.Forms.Label age1Label;
        private System.Windows.Forms.Label address1Llabel;
        private System.Windows.Forms.Label name1Label;
        private System.Windows.Forms.ListBox famliy_FriendsListBox;
        private System.Windows.Forms.ListBox myInfoListBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label SummaryLabel;
    }
}

