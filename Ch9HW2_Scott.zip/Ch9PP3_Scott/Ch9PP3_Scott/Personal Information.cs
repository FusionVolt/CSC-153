﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch9PP3_Scott
{
    public class Personal_Information
    {
        // Fields
        private string _name;
        private string _address;
        private int _age;
        private string _phoneNumber;

        // Constructor
        public Personal_Information()
        {
            _name = name;
            _address = address;
            _age = age;
            _phoneNumber = phone;
        }

        // Name property
        public string name
        {
            get { return _name; }
            set { _name = value; }
        }

        // Address property
        public string address
        {
            get { return _address; }
            set { _address = value; }
        }

        // Age property
        public int age
        {
            get { return _age; }
            set { _age = value; }
        }

        // Phone Number property
        public string phone
        {
            get { return _phoneNumber; }
            set { _phoneNumber = value; }
        }
    }
}
