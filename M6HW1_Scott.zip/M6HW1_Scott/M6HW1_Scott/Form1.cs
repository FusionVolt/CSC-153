﻿/**
* 4/20/2018
* CSC 153
* Cameron Scott
* This program calculate total distance an object has fall via methods.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M6HW1_Scott
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Private Void Method
        private void FallingDistance()
        {
            // Variables
            double g = 9.8;     // Gravity
            double d;           // Distance in meters
            double t;           // Amount of time the object has been fallen

            if (double.TryParse(timeDistanceTextBox.Text, out t))
            {
                // Fallen distance formula
                d = .5 * g * Math.Pow(t, 2);

                // Calculate the total distance 
                totalDistanceLabel.Text = d.ToString("n2") + " m";
            }
            else
            {
                // displays an error input message
                MessageBox.Show("Invalid input for seconds");
                
                // clears the text
                timeDistanceTextBox.Text = "";
                
                // refocus the cursor upon clearing
                timeDistanceTextBox.Focus();
            }

        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // This button calculates the user input for total distace.
            // This calls the Mehods
            FallingDistance();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // This button clears the text
            timeDistanceTextBox.Text = "";
            totalDistanceLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // This closes the program
            this.Close();
        }

    }
}
