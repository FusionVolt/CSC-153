﻿namespace Ch9HW3_Group_2_
{
    partial class DormMealForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DormitoryGroupBox = new System.Windows.Forms.GroupBox();
            this.UniverseRadioButton = new System.Windows.Forms.RadioButton();
            this.farthingRadioButton = new System.Windows.Forms.RadioButton();
            this.pikeRadioButton = new System.Windows.Forms.RadioButton();
            this.allenRadioButton = new System.Windows.Forms.RadioButton();
            this.mealGroupBox = new System.Windows.Forms.GroupBox();
            this.unlimitedRadioButton = new System.Windows.Forms.RadioButton();
            this.meal14RadioButton = new System.Windows.Forms.RadioButton();
            this.meal7RadioButton = new System.Windows.Forms.RadioButton();
            this.testButton = new System.Windows.Forms.Button();
            this.closebutton = new System.Windows.Forms.Button();
            this.DormitoryGroupBox.SuspendLayout();
            this.mealGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // DormitoryGroupBox
            // 
            this.DormitoryGroupBox.Controls.Add(this.UniverseRadioButton);
            this.DormitoryGroupBox.Controls.Add(this.farthingRadioButton);
            this.DormitoryGroupBox.Controls.Add(this.pikeRadioButton);
            this.DormitoryGroupBox.Controls.Add(this.allenRadioButton);
            this.DormitoryGroupBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DormitoryGroupBox.Location = new System.Drawing.Point(12, 12);
            this.DormitoryGroupBox.Name = "DormitoryGroupBox";
            this.DormitoryGroupBox.Size = new System.Drawing.Size(200, 124);
            this.DormitoryGroupBox.TabIndex = 0;
            this.DormitoryGroupBox.TabStop = false;
            this.DormitoryGroupBox.Text = "Dormitory";
            // 
            // UniverseRadioButton
            // 
            this.UniverseRadioButton.AutoSize = true;
            this.UniverseRadioButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UniverseRadioButton.Location = new System.Drawing.Point(10, 97);
            this.UniverseRadioButton.Name = "UniverseRadioButton";
            this.UniverseRadioButton.Size = new System.Drawing.Size(117, 19);
            this.UniverseRadioButton.TabIndex = 3;
            this.UniverseRadioButton.Text = "University Suites";
            this.UniverseRadioButton.UseVisualStyleBackColor = true;
            // 
            // farthingRadioButton
            // 
            this.farthingRadioButton.AutoSize = true;
            this.farthingRadioButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.farthingRadioButton.Location = new System.Drawing.Point(10, 72);
            this.farthingRadioButton.Name = "farthingRadioButton";
            this.farthingRadioButton.Size = new System.Drawing.Size(94, 19);
            this.farthingRadioButton.TabIndex = 2;
            this.farthingRadioButton.Text = "Farthing Hall";
            this.farthingRadioButton.UseVisualStyleBackColor = true;
            // 
            // pikeRadioButton
            // 
            this.pikeRadioButton.AutoSize = true;
            this.pikeRadioButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pikeRadioButton.Location = new System.Drawing.Point(10, 47);
            this.pikeRadioButton.Name = "pikeRadioButton";
            this.pikeRadioButton.Size = new System.Drawing.Size(71, 19);
            this.pikeRadioButton.TabIndex = 1;
            this.pikeRadioButton.Text = "Pike Hall";
            this.pikeRadioButton.UseVisualStyleBackColor = true;
            // 
            // allenRadioButton
            // 
            this.allenRadioButton.AutoSize = true;
            this.allenRadioButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.allenRadioButton.Location = new System.Drawing.Point(10, 22);
            this.allenRadioButton.Name = "allenRadioButton";
            this.allenRadioButton.Size = new System.Drawing.Size(78, 19);
            this.allenRadioButton.TabIndex = 0;
            this.allenRadioButton.Text = "Allen Hall";
            this.allenRadioButton.UseVisualStyleBackColor = true;
            // 
            // mealGroupBox
            // 
            this.mealGroupBox.Controls.Add(this.unlimitedRadioButton);
            this.mealGroupBox.Controls.Add(this.meal14RadioButton);
            this.mealGroupBox.Controls.Add(this.meal7RadioButton);
            this.mealGroupBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mealGroupBox.Location = new System.Drawing.Point(256, 12);
            this.mealGroupBox.Name = "mealGroupBox";
            this.mealGroupBox.Size = new System.Drawing.Size(200, 124);
            this.mealGroupBox.TabIndex = 0;
            this.mealGroupBox.TabStop = false;
            this.mealGroupBox.Text = "Meal Plan";
            // 
            // unlimitedRadioButton
            // 
            this.unlimitedRadioButton.AutoSize = true;
            this.unlimitedRadioButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unlimitedRadioButton.Location = new System.Drawing.Point(15, 72);
            this.unlimitedRadioButton.Name = "unlimitedRadioButton";
            this.unlimitedRadioButton.Size = new System.Drawing.Size(109, 19);
            this.unlimitedRadioButton.TabIndex = 3;
            this.unlimitedRadioButton.Text = "Unlimited meals";
            this.unlimitedRadioButton.UseVisualStyleBackColor = true;
            // 
            // meal14RadioButton
            // 
            this.meal14RadioButton.AutoSize = true;
            this.meal14RadioButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.meal14RadioButton.Location = new System.Drawing.Point(15, 47);
            this.meal14RadioButton.Name = "meal14RadioButton";
            this.meal14RadioButton.Size = new System.Drawing.Size(120, 19);
            this.meal14RadioButton.TabIndex = 2;
            this.meal14RadioButton.Text = "14 meals per week";
            this.meal14RadioButton.UseVisualStyleBackColor = true;
            // 
            // meal7RadioButton
            // 
            this.meal7RadioButton.AutoSize = true;
            this.meal7RadioButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.meal7RadioButton.Location = new System.Drawing.Point(15, 22);
            this.meal7RadioButton.Name = "meal7RadioButton";
            this.meal7RadioButton.Size = new System.Drawing.Size(114, 19);
            this.meal7RadioButton.TabIndex = 1;
            this.meal7RadioButton.Text = "7 meals per week";
            this.meal7RadioButton.UseVisualStyleBackColor = true;
            // 
            // testButton
            // 
            this.testButton.Location = new System.Drawing.Point(99, 155);
            this.testButton.Name = "testButton";
            this.testButton.Size = new System.Drawing.Size(115, 23);
            this.testButton.TabIndex = 2;
            this.testButton.Text = "Calculate Summay";
            this.testButton.UseVisualStyleBackColor = true;
            this.testButton.Click += new System.EventHandler(this.testButton_Click);
            // 
            // closebutton
            // 
            this.closebutton.Location = new System.Drawing.Point(256, 155);
            this.closebutton.Name = "closebutton";
            this.closebutton.Size = new System.Drawing.Size(115, 23);
            this.closebutton.TabIndex = 3;
            this.closebutton.Text = "Close";
            this.closebutton.UseVisualStyleBackColor = true;
            this.closebutton.Click += new System.EventHandler(this.closebutton_Click);
            // 
            // DormMealForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(482, 197);
            this.Controls.Add(this.closebutton);
            this.Controls.Add(this.testButton);
            this.Controls.Add(this.mealGroupBox);
            this.Controls.Add(this.DormitoryGroupBox);
            this.Name = "DormMealForm";
            this.Text = "Dorm and Meal Plan Calculator";
            this.DormitoryGroupBox.ResumeLayout(false);
            this.DormitoryGroupBox.PerformLayout();
            this.mealGroupBox.ResumeLayout(false);
            this.mealGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        public System.Windows.Forms.GroupBox DormitoryGroupBox;
        public System.Windows.Forms.GroupBox mealGroupBox;
        public System.Windows.Forms.Button testButton;
        public System.Windows.Forms.RadioButton UniverseRadioButton;
        public System.Windows.Forms.RadioButton farthingRadioButton;
        public System.Windows.Forms.RadioButton pikeRadioButton;
        public System.Windows.Forms.RadioButton unlimitedRadioButton;
        public System.Windows.Forms.RadioButton meal14RadioButton;
        public System.Windows.Forms.RadioButton meal7RadioButton;
        public System.Windows.Forms.RadioButton allenRadioButton;
        public System.Windows.Forms.Button closebutton;
    }
}

