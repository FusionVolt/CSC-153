﻿/**
* 05/09/2018
* CSC 153
* Cameron Scott
* This program calculates the grand total for both dormitory and meal plan using multiple forms
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9HW3_Group_2_
{
    public partial class DormMealForm : Form
    {
        // Classes
        Dorm _dorm = new Dorm();
        Meal_Plan _meal = new Meal_Plan();
        
        public DormMealForm()
        {
            InitializeComponent();
        }

        private void testButton_Click(object sender, EventArgs e)
        {
            // Select a Dormitory
            bool Dorm = false;

            if (allenRadioButton.Checked)
            {
               Dorm = true;
                _dorm.dormCost = _dorm.allenHall;
                _dorm.dormName = "'Allen Hall'";
            }
            else if (pikeRadioButton.Checked)
            {
                Dorm = true;
                _dorm.dormCost = _dorm.pikeHall;
                _dorm.dormName = "'Pike Hall'";
            }
            else if (farthingRadioButton.Checked)
            {
                Dorm = true;
                _dorm.dormCost = _dorm.farthingHall;
                _dorm.dormName = "'Farthing Hall'";
            }
            else if (UniverseRadioButton.Checked)
            {
                Dorm = true;
                _dorm.dormCost = _dorm.universitySuites;
                _dorm.dormName = "'University Suites'";
            }


            // Select a Meal Plan
            bool Meal_Plan = false;

            if (meal7RadioButton.Checked)
            {
                Meal_Plan = true;
                _meal.mealCost = _meal.meal7;
                _meal.planMeal = "With 7 meals a week,";
            }

            else if (meal14RadioButton.Checked)
            {
                Meal_Plan = true;
                _meal.mealCost = _meal.meal14;
                _meal.planMeal = "With 14 meals a week,";
            }

            else if (unlimitedRadioButton.Checked)
            {
                Meal_Plan = true;
                _meal.mealCost = _meal.mealUnlimited;
                _meal.planMeal = "With unlimited amount of meals,";
            }

            // Verify both dormitory and meal plan are selected.
            if (Dorm == true && Meal_Plan == true)
            {
                double dormtest = _dorm.dormCost + _meal.mealCost;

                SummaryForm summaryForm = new SummaryForm();
                summaryForm.dormSummaryLabel.Text = "The dormitory " + _dorm.dormName + " will cost " + _dorm.dormCost.ToString("c") + " dollars.";
                summaryForm.mealSummaryLabel.Text = _meal.planMeal + " this will cost " + _meal.mealCost.ToString("c") + " dollars for this meal plan.";
                summaryForm.tuitionLabel.Text = "The grand total of both the dormitory and meal plan will set you " + dormtest.ToString("c") + " dollars.";
                summaryForm.ShowDialog();
            }
            else
            {

                if (Dorm == false && Meal_Plan == false)
                {
                    MessageBox.Show("Must choose both the dormitory and meal plan.");
                    
                }
                else if(Dorm == false)
                {
                    MessageBox.Show("Please select a dormitory.");
                    
                }
                else if(Meal_Plan == false)
                {
                    MessageBox.Show("Please select a meal plan.");
                }
            }
            
        }

        private void closebutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
