﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch9HW3_Group_2_
{
    public class Dorm
    {
        // Fields
        // private doubles are the price for each dormitory
        private double _allenHall;
        private double _pikeHall;
        private double _farthingHall;
        private double _universitySuites;
        private double _dormCost;               // Holds the cost for dormitory 
        private string _dormName;               // Name of dormitory

        // Constructor

        public Dorm()
        {
            _allenHall = 1500;
            _pikeHall = 1600;
            _farthingHall = 1800;
            _universitySuites = 2500;
            _dormCost = 0;
            _dormName = "";
        }

        // Allen Hall property
        public double allenHall
        {
            get { return _allenHall; }
            set { _allenHall = value; }
        }

        // Pike Hall property
        public double pikeHall
        {
            get { return _pikeHall; }
            set { _pikeHall = value; }
        }

        // Farthing Hall property
        public double farthingHall
        {
            get { return _farthingHall; }
            set { _farthingHall = value; }
        }

        // University Suites property
        public double universitySuites
        {
            get { return _universitySuites; }
            set { _universitySuites = value; }
        }
        
        // Dormitory property
        public double dormCost
        {
            get { return _dormCost; }
            set { _dormCost = value; }
        }

        // Dormitory name property
        public string dormName
        {
            get { return _dormName; }
            set { _dormName = value; }
        }
    }
}
