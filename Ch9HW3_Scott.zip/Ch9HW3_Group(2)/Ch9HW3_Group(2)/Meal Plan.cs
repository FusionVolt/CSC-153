﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch9HW3_Group_2_
{
    public class Meal_Plan
    {
        // Field
        // First three of private doubles are placeholders for meal plan cost.
        private double _meal7;
        private double _meal14;
        private double _mealUnlimited;
        private double _mealCost;           // Holds the price for meal plans
        private string _planMeal;           // Name of meal plans

        // Constructor
        public Meal_Plan()
        {
            _meal7 = 600;
            _meal14 = 1200;
            _mealUnlimited = 1700;
            _mealCost = 0;
            _planMeal = "";
        }

        // 7 Meals a week property
        public double meal7
        {
            get { return _meal7; }
            set { _meal7 = value; }
        }

        // 14 Meals a week property
        public double meal14
        {
            get { return _meal14; }
            set { _meal14 = value; }
        }

        // Unlimited Meals property
        public double mealUnlimited
        {
            get { return _mealUnlimited; }
            set { _mealUnlimited = value; }
        }

        // Meal Cost property
        public double mealCost
        {
            get { return _mealCost; }
            set { _mealCost = value; }
        }

        // Meal Plan property
        public string planMeal
        {
            get { return _planMeal; }
            set { _planMeal = value; }
        }
    }
}
