﻿namespace Ch9HW3_Group_2_
{
    partial class SummaryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ExitButton = new System.Windows.Forms.Button();
            this.dormSummaryLabel = new System.Windows.Forms.Label();
            this.mealSummaryLabel = new System.Windows.Forms.Label();
            this.tuitionLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(229, 143);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(75, 23);
            this.ExitButton.TabIndex = 5;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // dormSummaryLabel
            // 
            this.dormSummaryLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dormSummaryLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dormSummaryLabel.Location = new System.Drawing.Point(12, 22);
            this.dormSummaryLabel.Name = "dormSummaryLabel";
            this.dormSummaryLabel.Size = new System.Drawing.Size(516, 23);
            this.dormSummaryLabel.TabIndex = 6;
            this.dormSummaryLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mealSummaryLabel
            // 
            this.mealSummaryLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.mealSummaryLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mealSummaryLabel.Location = new System.Drawing.Point(12, 63);
            this.mealSummaryLabel.Name = "mealSummaryLabel";
            this.mealSummaryLabel.Size = new System.Drawing.Size(516, 23);
            this.mealSummaryLabel.TabIndex = 7;
            this.mealSummaryLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tuitionLabel
            // 
            this.tuitionLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tuitionLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tuitionLabel.Location = new System.Drawing.Point(12, 107);
            this.tuitionLabel.Name = "tuitionLabel";
            this.tuitionLabel.Size = new System.Drawing.Size(516, 23);
            this.tuitionLabel.TabIndex = 8;
            this.tuitionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // SummaryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(535, 185);
            this.Controls.Add(this.tuitionLabel);
            this.Controls.Add(this.mealSummaryLabel);
            this.Controls.Add(this.dormSummaryLabel);
            this.Controls.Add(this.ExitButton);
            this.Name = "SummaryForm";
            this.Text = "Dormitory and Meal Summary";
            this.ResumeLayout(false);

        }

        #endregion
        public System.Windows.Forms.Button ExitButton;
        public System.Windows.Forms.Label dormSummaryLabel;
        public System.Windows.Forms.Label mealSummaryLabel;
        public System.Windows.Forms.Label tuitionLabel;
    }
}